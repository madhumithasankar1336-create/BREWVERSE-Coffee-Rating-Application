# BREWVERSE – Discover. Vote. Enjoy.

A full-stack Coffee Rating, Live Community Voting, and Analytics platform built with **HTML5**, **CSS3**, **Vanilla JavaScript**, **Node.js**, **Express.js**, and **MongoDB (Mongoose)**.

---

## Project Structure

```
BREWVERSE/
├── frontend/
│   ├── index.html             # Homepage, Hero, Coffee of the Day, Collection, Battle, Quiz, Favorites
│   ├── coffee-details.html    # Detailed brew breakdown & community reviews
│   ├── leaderboard.html       # Top 5 Leaderboard & Voting Analytics Dashboard
│   ├── profile.html           # User profile, active votes, favorites & reviews
│   ├── login.html             # Sign in page
│   ├── register.html          # Registration page
│   ├── css/style.css          # Coffee-house palette, glassmorphism, dark/light theme
│   ├── js/
│   │   ├── app.js             # Page initialization & details/profile/auth controllers
│   │   ├── auth.js            # JWT session management, theme + WebGL2 Beams sync, Fetch wrapper
│   │   ├── beams.js           # Vanilla JS WebGL2 shader background
│   │   ├── coffees.js         # Collection grid, smart search, Coffee Battle, Personality Quiz
│   │   ├── voting.js          # Vote & favorite mutations + animated counters
│   │   ├── analytics.js       # Leaderboard & Canvas 2D charts
│   │   └── icons.js           # Inline Lucide SVG icons
│   └── assets/images/         # Coffee photography assets
├── backend/
│   ├── config/db.js           # MongoDB / Mongoose connection (+ automatic fallback to MongoMemoryServer)
│   ├── models/                # Coffee, User, Vote, Review Mongoose schemas
│   ├── controllers/           # REST API controllers
│   ├── routes/                # Express routers
│   ├── middleware/auth.js     # JWT Bearer protection middleware
│   ├── data/seedCoffees.js    # Initial 10 coffees, demo accounts, real votes & reviews
│   ├── app.js                 # Express application factory
│   ├── server.js              # Standalone backend entry point (port 5000)
│   └── .env.example           # Backend environment template
├── server.ts                  # Unified server entry point (port 3000)
├── package.json
└── .env.example
```

---

## 1. Install Dependencies

```bash
npm install
```

---

## 2. Configure MongoDB & Environment Variables

Copy the example environment file:

```bash
cp .env.example .env
```

Update `.env` with your MongoDB connection string and JWT secret:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/brewverse
JWT_SECRET=your_strong_jwt_secret
JWT_EXPIRES_IN=7d
```

> Note: If a local or Atlas MongoDB instance is unavailable at `MONGODB_URI`, `backend/config/db.js` automatically starts an embedded `mongodb-memory-server` instance and seeds the 10 coffees, community votes, and reviews so the app runs immediately.

---

## 3. Start the Backend Server (Port 5000)

```bash
npm run backend
```

This runs `node backend/server.js` on `http://localhost:5000` and serves both the `/api/*` endpoints and the `frontend/` static files.

---

## 4. Run the Full-Stack Dev Server (Port 3000)

```bash
npm run dev
```

Visit `http://localhost:3000` in your browser.

---

## 5. Test API Endpoints Using Postman

Demo taster account seeded automatically:
- **Email:** `barista@brewverse.com`
- **Password:** `Password123!`

### Authentication
- `POST http://localhost:5000/api/auth/register` — Body: `{ "name": "Alex", "email": "alex@example.com", "password": "Password123!" }`
- `POST http://localhost:5000/api/auth/login` — Body: `{ "email": "barista@brewverse.com", "password": "Password123!" }` (copy returned `token`)
- `GET http://localhost:5000/api/auth/me` — Header: `Authorization: Bearer <token>`

### Coffees
- `GET http://localhost:5000/api/coffees?search=latte&sort=popular`
- `GET http://localhost:5000/api/coffees/:id`
- `GET http://localhost:5000/api/coffees/featured/today`
- `GET http://localhost:5000/api/coffees/random`
- `POST http://localhost:5000/api/coffees` (Bearer token required)
- `PUT http://localhost:5000/api/coffees/:id` (Bearer token required)
- `DELETE http://localhost:5000/api/coffees/:id` (Bearer token required)

### Voting & Analytics
- `POST http://localhost:5000/api/votes` (Bearer token required) — Body: `{ "coffeeId": "<coffee_id>" }`
- `GET http://localhost:5000/api/votes/:coffeeId`
- `GET http://localhost:5000/api/leaderboard`
- `GET http://localhost:5000/api/analytics`

### Reviews & Favorites
- `POST http://localhost:5000/api/reviews` (Bearer token required) — Body: `{ "coffeeId": "<coffee_id>", "rating": 5, "comment": "Bright jasmine notes!" }`
- `GET http://localhost:5000/api/reviews/:coffeeId`
- `POST http://localhost:5000/api/favorites` (Bearer token required) — Body: `{ "coffeeId": "<coffee_id>" }`
- `GET http://localhost:5000/api/favorites` (Bearer token required)
- `DELETE http://localhost:5000/api/favorites/:coffeeId` (Bearer token required)
