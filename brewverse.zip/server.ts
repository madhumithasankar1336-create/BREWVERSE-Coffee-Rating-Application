import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import { connectDB } from './backend/config/db.js';
import { seedDatabaseIfEmpty } from './backend/data/seedCoffees.js';
import { createApiApp } from './backend/app.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendDir = path.resolve(__dirname, 'frontend');

const PORT = Number(process.env.PORT) || 3000;

async function start() {
  try {
    await connectDB();
    await seedDatabaseIfEmpty();

    const app = createApiApp();
    app.use(express.static(frontendDir));

    app.get('/', (_req, res) => {
      res.sendFile(path.join(frontendDir, 'index.html'));
    });

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`BREWVERSE full-stack server running on http://0.0.0.0:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start BREWVERSE server:', err);
    process.exit(1);
  }
}

start();
