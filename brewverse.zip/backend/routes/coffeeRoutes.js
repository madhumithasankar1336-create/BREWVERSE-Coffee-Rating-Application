import express from 'express';
import {
  getCoffees,
  getCoffeeById,
  getFeaturedToday,
  getRandomCoffee,
  createCoffee,
  updateCoffee,
  deleteCoffee,
} from '../controllers/coffeeController.js';
import { protect, optionalAuth } from '../middleware/auth.js';

const router = express.Router();

router.get('/', optionalAuth, getCoffees);
router.get('/featured/today', getFeaturedToday);
router.get('/random', getRandomCoffee);
router.get('/:id', optionalAuth, getCoffeeById);
router.post('/', protect, createCoffee);
router.put('/:id', protect, updateCoffee);
router.delete('/:id', protect, deleteCoffee);

export default router;
