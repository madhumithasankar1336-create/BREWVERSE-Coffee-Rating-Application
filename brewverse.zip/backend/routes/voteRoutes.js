import express from 'express';
import {
  castOrToggleVote,
  getMyVotes,
  getVotesByCoffee,
} from '../controllers/voteController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.post('/', protect, castOrToggleVote);
router.get('/my', protect, getMyVotes);
router.get('/:coffeeId', getVotesByCoffee);

export default router;
