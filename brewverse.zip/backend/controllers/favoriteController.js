import mongoose from 'mongoose';
import Coffee from '../models/Coffee.js';
import User from '../models/User.js';

export async function addFavorite(req, res) {
  try {
    const { coffeeId } = req.body;
    if (!coffeeId || !mongoose.Types.ObjectId.isValid(coffeeId)) {
      return res.status(400).json({ success: false, message: 'Valid coffeeId is required.' });
    }

    const coffee = await Coffee.findById(coffeeId);
    if (!coffee) {
      return res.status(404).json({ success: false, message: 'Coffee not found.' });
    }

    const user = await User.findById(req.user._id);
    const exists = user.favorites.some((id) => id.toString() === coffeeId);

    if (!exists) {
      user.favorites.push(coffeeId);
      await user.save();
    }

    const populated = await User.findById(req.user._id).populate('favorites');

    return res.status(200).json({
      success: true,
      favorited: true,
      message: `${coffee.name} saved to favorites.`,
      favorites: populated.favorites,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to save favorite.',
    });
  }
}

export async function getFavorites(req, res) {
  try {
    const user = await User.findById(req.user._id).populate('favorites');
    return res.json({
      success: true,
      favorites: user?.favorites || [],
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to load favorites.',
    });
  }
}

export async function removeFavorite(req, res) {
  try {
    const { coffeeId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(coffeeId)) {
      return res.status(400).json({ success: false, message: 'Invalid coffeeId.' });
    }

    const user = await User.findById(req.user._id);
    user.favorites = user.favorites.filter((id) => id.toString() !== coffeeId);
    await user.save();

    const populated = await User.findById(req.user._id).populate('favorites');

    return res.json({
      success: true,
      favorited: false,
      message: 'Removed from favorites.',
      favorites: populated.favorites,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to remove favorite.',
    });
  }
}
