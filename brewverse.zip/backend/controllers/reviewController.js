import mongoose from 'mongoose';
import Coffee from '../models/Coffee.js';
import Review from '../models/Review.js';

export async function createReview(req, res) {
  try {
    const { coffeeId, rating, comment } = req.body;
    const userId = req.user._id;

    if (!coffeeId || !mongoose.Types.ObjectId.isValid(coffeeId)) {
      return res.status(400).json({ success: false, message: 'Valid coffeeId is required.' });
    }

    const numericRating = Number(rating);
    if (!numericRating || numericRating < 1 || numericRating > 5) {
      return res.status(400).json({
        success: false,
        message: 'Rating must be between 1 and 5.',
      });
    }

    if (!comment || String(comment).trim().length < 3) {
      return res.status(400).json({
        success: false,
        message: 'Please write a review comment (at least 3 characters).',
      });
    }

    const coffee = await Coffee.findById(coffeeId);
    if (!coffee) {
      return res.status(404).json({ success: false, message: 'Coffee not found.' });
    }

    const review = await Review.create({
      userId,
      coffeeId,
      rating: numericRating,
      comment: String(comment).trim(),
    });

    const allReviews = await Review.find({ coffeeId });
    const avg =
      allReviews.reduce((acc, r) => acc + r.rating, 0) / Math.max(allReviews.length, 1);

    coffee.averageRating = Number(avg.toFixed(2));
    coffee.reviewCount = allReviews.length;
    await coffee.save();

    const populated = await Review.findById(review._id).populate('userId', 'name');

    return res.status(201).json({
      success: true,
      message: 'Review published successfully.',
      review: populated,
      averageRating: coffee.averageRating,
      reviewCount: coffee.reviewCount,
    });
  } catch (err) {
    return res.status(400).json({
      success: false,
      message: err.message || 'Unable to submit review.',
    });
  }
}

export async function getReviewsByCoffee(req, res) {
  try {
    const { coffeeId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(coffeeId)) {
      return res.status(400).json({ success: false, message: 'Invalid coffeeId.' });
    }

    const reviews = await Review.find({ coffeeId })
      .populate('userId', 'name')
      .sort({ createdAt: -1 });

    return res.json({
      success: true,
      count: reviews.length,
      reviews,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to load reviews.',
    });
  }
}
