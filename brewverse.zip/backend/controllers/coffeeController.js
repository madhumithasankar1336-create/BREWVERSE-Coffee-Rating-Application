import mongoose from 'mongoose';
import Coffee from '../models/Coffee.js';
import Vote from '../models/Vote.js';
import Review from '../models/Review.js';

export async function getCoffees(req, res) {
  try {
    const { search, category, sort, trending } = req.query;
    const filter = {};

    if (search && search.trim()) {
      const regex = new RegExp(search.trim(), 'i');
      filter.$or = [
        { name: regex },
        { description: regex },
        { origin: regex },
        { category: regex },
        { flavorProfile: regex },
      ];
    }

    if (category && category !== 'All') {
      filter.category = category;
    }

    if (trending === 'true') {
      filter.isTrending = true;
    }

    let sortObj = { totalVotes: -1, averageRating: -1, name: 1 };
    if (sort === 'rating') {
      sortObj = { averageRating: -1, totalVotes: -1 };
    } else if (sort === 'trending') {
      sortObj = { isTrending: -1, totalVotes: -1 };
    } else if (sort === 'name') {
      sortObj = { name: 1 };
    } else if (sort === 'newest') {
      sortObj = { createdAt: -1 };
    }

    const coffees = await Coffee.find(filter).sort(sortObj);

    let userVotedIds = [];
    if (req.user) {
      const votes = await Vote.find({ userId: req.user._id }).select('coffeeId');
      userVotedIds = votes.map((v) => v.coffeeId.toString());
    }

    return res.json({
      success: true,
      count: coffees.length,
      userVotedIds,
      coffees,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to load coffee collection.',
    });
  }
}

export async function getCoffeeById(req, res) {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: 'Invalid coffee ID format.' });
    }

    const coffee = await Coffee.findById(id);
    if (!coffee) {
      return res.status(404).json({ success: false, message: 'Coffee not found.' });
    }

    const reviews = await Review.find({ coffeeId: id })
      .populate('userId', 'name')
      .sort({ createdAt: -1 });

    let hasVoted = false;
    if (req.user) {
      const existingVote = await Vote.findOne({ userId: req.user._id, coffeeId: id });
      hasVoted = Boolean(existingVote);
    }

    return res.json({
      success: true,
      coffee,
      reviews,
      hasVoted,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to load coffee details.',
    });
  }
}

export async function getFeaturedToday(req, res) {
  try {
    const coffees = await Coffee.find().sort({ totalVotes: -1, averageRating: -1 });
    if (coffees.length === 0) {
      return res.status(404).json({ success: false, message: 'No coffees available.' });
    }

    // Deterministic daily index based on UTC day so Coffee of the Day rotates daily
    const dayIndex = Math.floor(Date.now() / (1000 * 60 * 60 * 24)) % coffees.length;
    const featured = coffees[dayIndex];

    return res.json({
      success: true,
      coffee: featured,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch Coffee of the Day.',
    });
  }
}

export async function getRandomCoffee(req, res) {
  try {
    const excludeId = req.query.exclude;
    const filter = excludeId && mongoose.Types.ObjectId.isValid(excludeId)
      ? { _id: { $ne: excludeId } }
      : {};
    const coffees = await Coffee.find(filter);
    if (coffees.length === 0) {
      const all = await Coffee.find();
      if (all.length === 0) {
        return res.status(404).json({ success: false, message: 'No coffees found.' });
      }
      return res.json({ success: true, coffee: all[0] });
    }

    const randomIndex = Math.floor(Math.random() * coffees.length);
    return res.json({
      success: true,
      coffee: coffees[randomIndex],
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to select a random coffee.',
    });
  }
}

export async function createCoffee(req, res) {
  try {
    const {
      name,
      description,
      image,
      category,
      ingredients,
      origin,
      flavorProfile,
      caffeineLevel,
      tasteProfile,
      isTrending,
    } = req.body;

    if (!name || !description || !category || !origin || !caffeineLevel) {
      return res.status(400).json({
        success: false,
        message: 'Name, description, category, origin, and caffeine level are required.',
      });
    }

    const parsedIngredients = Array.isArray(ingredients)
      ? ingredients
      : String(ingredients || '')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean);

    if (parsedIngredients.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide at least one ingredient.',
      });
    }

    const parsedFlavors = Array.isArray(flavorProfile)
      ? flavorProfile
      : String(flavorProfile || '')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean);

    const coffee = await Coffee.create({
      name: name.trim(),
      description: description.trim(),
      image: image && image.trim() ? image.trim() : '/assets/images/espresso.jpg',
      category,
      ingredients: parsedIngredients,
      origin: origin.trim(),
      flavorProfile: parsedFlavors,
      caffeineLevel,
      tasteProfile: tasteProfile || 'Strong',
      isTrending: Boolean(isTrending),
    });

    return res.status(201).json({
      success: true,
      message: `${coffee.name} added to BREWVERSE.`,
      coffee,
    });
  } catch (err) {
    const status = err.code === 11000 ? 409 : 400;
    return res.status(status).json({
      success: false,
      message: err.code === 11000 ? 'A coffee with this name already exists.' : err.message,
    });
  }
}

export async function updateCoffee(req, res) {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: 'Invalid coffee ID.' });
    }

    const updates = { ...req.body };
    delete updates.totalVotes;
    delete updates.averageRating;
    delete updates.reviewCount;

    const coffee = await Coffee.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    });

    if (!coffee) {
      return res.status(404).json({ success: false, message: 'Coffee not found.' });
    }

    return res.json({
      success: true,
      message: `${coffee.name} updated.`,
      coffee,
    });
  } catch (err) {
    return res.status(400).json({
      success: false,
      message: err.message || 'Failed to update coffee.',
    });
  }
}

export async function deleteCoffee(req, res) {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: 'Invalid coffee ID.' });
    }

    const coffee = await Coffee.findByIdAndDelete(id);
    if (!coffee) {
      return res.status(404).json({ success: false, message: 'Coffee not found.' });
    }

    await Vote.deleteMany({ coffeeId: id });
    await Review.deleteMany({ coffeeId: id });

    return res.json({
      success: true,
      message: `${coffee.name} removed from collection.`,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to delete coffee.',
    });
  }
}
