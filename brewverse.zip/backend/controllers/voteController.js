import mongoose from 'mongoose';
import Coffee from '../models/Coffee.js';
import Vote from '../models/Vote.js';

async function syncCoffeeVoteCount(coffeeId) {
  const count = await Vote.countDocuments({ coffeeId });
  await Coffee.findByIdAndUpdate(coffeeId, { totalVotes: count });
  return count;
}

export async function castOrToggleVote(req, res) {
  try {
    const { coffeeId, action, switchFromCoffeeId } = req.body;
    const userId = req.user._id;

    if (!coffeeId || !mongoose.Types.ObjectId.isValid(coffeeId)) {
      return res.status(400).json({
        success: false,
        message: 'A valid coffeeId is required.',
      });
    }

    const coffee = await Coffee.findById(coffeeId);
    if (!coffee) {
      return res.status(404).json({
        success: false,
        message: 'Coffee not found.',
      });
    }

    // Optional vote switch (e.g. changing vote from one coffee to another in Coffee Battle)
    if (switchFromCoffeeId && mongoose.Types.ObjectId.isValid(switchFromCoffeeId) && switchFromCoffeeId !== coffeeId) {
      await Vote.deleteOne({ userId, coffeeId: switchFromCoffeeId });
      await syncCoffeeVoteCount(switchFromCoffeeId);
    }

    const existingVote = await Vote.findOne({ userId, coffeeId });

    if (existingVote) {
      if (action === 'add') {
        return res.status(409).json({
          success: false,
          alreadyVoted: true,
          message: `You have already voted for ${coffee.name}.`,
          totalVotes: coffee.totalVotes,
        });
      }

      // Toggle/remove vote
      await Vote.deleteOne({ _id: existingVote._id });
      const totalVotes = await syncCoffeeVoteCount(coffeeId);
      const userVotes = await Vote.find({ userId }).select('coffeeId');

      return res.json({
        success: true,
        voted: false,
        message: `Removed your vote from ${coffee.name}.`,
        coffeeId,
        totalVotes,
        userVotedIds: userVotes.map((v) => v.coffeeId.toString()),
      });
    }

    if (action === 'remove') {
      return res.status(404).json({
        success: false,
        message: 'No existing vote found to remove.',
      });
    }

    await Vote.create({ userId, coffeeId });
    const totalVotes = await syncCoffeeVoteCount(coffeeId);
    const userVotes = await Vote.find({ userId }).select('coffeeId');

    return res.status(201).json({
      success: true,
      voted: true,
      message: `Vote recorded for ${coffee.name}!`,
      coffeeId,
      totalVotes,
      userVotedIds: userVotes.map((v) => v.coffeeId.toString()),
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({
        success: false,
        message: 'Duplicate vote prevented.',
      });
    }
    return res.status(500).json({
      success: false,
      message: 'Failed to process vote.',
    });
  }
}

export async function getMyVotes(req, res) {
  try {
    const votes = await Vote.find({ userId: req.user._id }).select('coffeeId createdAt');
    return res.json({
      success: true,
      votedCoffeeIds: votes.map((v) => v.coffeeId.toString()),
      votes,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to load your votes.',
    });
  }
}

export async function getVotesByCoffee(req, res) {
  try {
    const { coffeeId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(coffeeId)) {
      return res.status(400).json({ success: false, message: 'Invalid coffeeId.' });
    }

    const coffee = await Coffee.findById(coffeeId).select('name totalVotes averageRating');
    if (!coffee) {
      return res.status(404).json({ success: false, message: 'Coffee not found.' });
    }

    const voteCount = await Vote.countDocuments({ coffeeId });

    return res.json({
      success: true,
      coffeeId,
      coffeeName: coffee.name,
      totalVotes: voteCount,
      averageRating: coffee.averageRating,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch coffee votes.',
    });
  }
}

export async function getLeaderboard(req, res) {
  try {
    const allCoffees = await Coffee.find().sort({ totalVotes: -1, averageRating: -1, name: 1 });
    const totalCommunityVotes = allCoffees.reduce((acc, c) => acc + c.totalVotes, 0);

    const topFive = allCoffees.slice(0, 5).map((coffee, idx) => ({
      rank: idx + 1,
      _id: coffee._id,
      name: coffee.name,
      category: coffee.category,
      origin: coffee.origin,
      image: coffee.image,
      totalVotes: coffee.totalVotes,
      averageRating: coffee.averageRating,
      percentage:
        totalCommunityVotes > 0
          ? Number(((coffee.totalVotes / totalCommunityVotes) * 100).toFixed(1))
          : 0,
    }));

    return res.json({
      success: true,
      totalCommunityVotes,
      leaderboard: topFive,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to load leaderboard.',
    });
  }
}

export async function getAnalytics(req, res) {
  try {
    const coffees = await Coffee.find().sort({ totalVotes: -1, averageRating: -1 });
    const totalVarieties = coffees.length;
    const totalVotes = coffees.reduce((acc, c) => acc + c.totalVotes, 0);

    const mostPopular = coffees[0] || null;
    const leastPopular = coffees.length > 0 ? coffees[coffees.length - 1] : null;
    const highestRated =
      [...coffees].sort((a, b) => b.averageRating - a.averageRating || b.totalVotes - a.totalVotes)[0] ||
      null;

    const distribution = coffees.map((c) => ({
      _id: c._id,
      name: c.name,
      category: c.category,
      totalVotes: c.totalVotes,
      averageRating: c.averageRating,
      reviewCount: c.reviewCount,
      percentage: totalVotes > 0 ? Number(((c.totalVotes / totalVotes) * 100).toFixed(1)) : 0,
    }));

    const categoryMap = new Map();
    for (const c of coffees) {
      const current = categoryMap.get(c.category) || { category: c.category, votes: 0, count: 0 };
      current.votes += c.totalVotes;
      current.count += 1;
      categoryMap.set(c.category, current);
    }

    return res.json({
      success: true,
      summary: {
        totalVotes,
        totalVarieties,
        mostPopular,
        leastPopular,
        highestRated,
      },
      distribution,
      categoryBreakdown: Array.from(categoryMap.values()),
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Failed to compute voting analytics.',
    });
  }
}
