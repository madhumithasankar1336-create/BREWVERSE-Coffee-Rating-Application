import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Vote from '../models/Vote.js';
import Review from '../models/Review.js';
import { getJwtSecret } from '../middleware/auth.js';

function signToken(userId) {
  return jwt.sign({ id: userId }, getJwtSecret(), {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

export async function register(req, res) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are all required.',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    const existing = await User.findOne({ email: email.toLowerCase().trim() });
    if (existing) {
      return res.status(409).json({
        success: false,
        message: 'An account with this email already exists.',
      });
    }

    const user = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
    });

    const token = signToken(user._id);

    return res.status(201).json({
      success: true,
      message: 'Welcome to BREWVERSE! Account created successfully.',
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        favorites: user.favorites,
        createdAt: user.createdAt,
      },
    });
  } catch (err) {
    return res.status(400).json({
      success: false,
      message: err.message || 'Registration failed.',
    });
  }
}

export async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.',
      });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    const token = signToken(user._id);

    return res.json({
      success: true,
      message: `Welcome back, ${user.name}!`,
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        favorites: user.favorites,
        createdAt: user.createdAt,
      },
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Login error. Please try again.',
    });
  }
}

export async function getProfile(req, res) {
  try {
    const user = await User.findById(req.user._id).populate('favorites');
    const votes = await Vote.find({ userId: req.user._id })
      .populate('coffeeId', 'name image category origin totalVotes averageRating')
      .sort({ createdAt: -1 });
    const reviews = await Review.find({ userId: req.user._id })
      .populate('coffeeId', 'name image category')
      .sort({ createdAt: -1 });

    return res.json({
      success: true,
      user,
      votes,
      reviews,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Unable to fetch user profile.',
    });
  }
}
