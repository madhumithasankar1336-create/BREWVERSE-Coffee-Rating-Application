import express from 'express';
import cors from 'cors';
import authRoutes from './routes/authRoutes.js';
import coffeeRoutes from './routes/coffeeRoutes.js';
import voteRoutes from './routes/voteRoutes.js';
import reviewRoutes from './routes/reviewRoutes.js';
import favoriteRoutes from './routes/favoriteRoutes.js';
import { getLeaderboard, getAnalytics } from './controllers/voteController.js';

export function createApiApp() {
  const app = express();

  app.use(cors());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true }));

  app.get('/api/health', (_req, res) => {
    res.json({ success: true, status: 'ok', service: 'BREWVERSE API' });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/coffees', coffeeRoutes);
  app.use('/api/votes', voteRoutes);
  app.get('/api/leaderboard', getLeaderboard);
  app.get('/api/analytics', getAnalytics);
  app.use('/api/reviews', reviewRoutes);
  app.use('/api/favorites', favoriteRoutes);

  // API 404 handler
  app.use('/api/*', (_req, res) => {
    res.status(404).json({
      success: false,
      message: 'API endpoint not found.',
    });
  });

  // Global error handler
  app.use((err, _req, res, _next) => {
    console.error('Unhandled API Error:', err);
    res.status(err.status || 500).json({
      success: false,
      message: err.message || 'Internal server error.',
    });
  });

  return app;
}
