import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let memoryServer = null;

export async function connectDB() {
  const configuredUri = process.env.MONGODB_URI;

  if (configuredUri) {
    try {
      await mongoose.connect(configuredUri, {
        serverSelectionTimeoutMS: 4000,
      });
      console.log(`MongoDB connected: ${mongoose.connection.host}`);
      return mongoose.connection;
    } catch (err) {
      console.warn(
        `Unable to connect to configured MONGODB_URI (${err.message}). Falling back to embedded MongoDB instance.`
      );
    }
  }

  try {
    if (!memoryServer) {
      memoryServer = await MongoMemoryServer.create();
    }
    const uri = memoryServer.getUri();
    await mongoose.connect(uri);
    console.log(`Embedded MongoDB connected: ${uri}`);
    return mongoose.connection;
  } catch (err) {
    console.error('MongoDB connection failure:', err);
    throw new Error('Failed to connect to MongoDB database.');
  }
}

export async function disconnectDB() {
  await mongoose.disconnect();
  if (memoryServer) {
    await memoryServer.stop();
    memoryServer = null;
  }
}
