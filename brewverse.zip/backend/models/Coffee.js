import mongoose from 'mongoose';

const coffeeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Coffee name is required'],
      trim: true,
      unique: true,
      maxlength: [100, 'Coffee name cannot exceed 100 characters'],
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      maxlength: [1000, 'Description cannot exceed 1000 characters'],
    },
    image: {
      type: String,
      required: [true, 'Coffee image URL is required'],
      trim: true,
    },
    category: {
      type: String,
      required: [true, 'Coffee category is required'],
      enum: ['Single Origin', 'Espresso', 'Cold Brew', 'Specialty Latte', 'Tea Latte'],
    },
    ingredients: {
      type: [String],
      required: [true, 'Ingredients list is required'],
      validate: {
        validator: (arr) => Array.isArray(arr) && arr.length > 0,
        message: 'Provide at least one ingredient',
      },
    },
    origin: {
      type: String,
      required: [true, 'Origin is required'],
      trim: true,
    },
    flavorProfile: {
      type: [String],
      default: [],
    },
    caffeineLevel: {
      type: String,
      required: [true, 'Caffeine level is required'],
      enum: ['Low', 'Medium', 'High', 'Very High'],
    },
    tasteProfile: {
      type: String,
      enum: ['Strong', 'Sweet', 'Creamy', 'Refreshing'],
      default: 'Strong',
    },
    isTrending: {
      type: Boolean,
      default: false,
    },
    totalVotes: {
      type: Number,
      default: 0,
      min: 0,
    },
    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5,
    },
    reviewCount: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  {
    timestamps: true,
  }
);

coffeeSchema.index({ name: 'text', description: 'text', origin: 'text', category: 'text' });
coffeeSchema.index({ totalVotes: -1 });
coffeeSchema.index({ averageRating: -1 });

const Coffee = mongoose.models.Coffee || mongoose.model('Coffee', coffeeSchema);
export default Coffee;
