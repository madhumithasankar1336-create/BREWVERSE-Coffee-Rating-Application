import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  coffeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Coffee',
    required: true,
  },
  rating: {
    type: Number,
    required: [true, 'Rating between 1 and 5 is required'],
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5'],
  },
  comment: {
    type: String,
    required: [true, 'Review comment is required'],
    trim: true,
    minlength: [3, 'Comment must be at least 3 characters'],
    maxlength: [600, 'Comment cannot exceed 600 characters'],
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

reviewSchema.index({ coffeeId: 1, createdAt: -1 });

const Review = mongoose.models.Review || mongoose.model('Review', reviewSchema);
export default Review;
