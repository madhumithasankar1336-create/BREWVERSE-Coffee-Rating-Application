import mongoose from 'mongoose';

const voteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  coffeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Coffee',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

voteSchema.index({ userId: 1, coffeeId: 1 }, { unique: true });

const Vote = mongoose.models.Vote || mongoose.model('Vote', voteSchema);
export default Vote;
