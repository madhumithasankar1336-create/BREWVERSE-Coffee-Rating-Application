import Coffee from '../models/Coffee.js';
import User from '../models/User.js';
import Vote from '../models/Vote.js';
import Review from '../models/Review.js';

export const SAMPLE_COFFEES = [
  {
    name: 'Ethiopian Yirgacheffe',
    description:
      'Washed high-altitude heirloom beans bursting with bergamot, white jasmine blossom, and crisp Meyer lemon clarity.',
    image: '/assets/images/ethiopian-yirgacheffe.jpg',
    category: 'Single Origin',
    ingredients: ['100% Ethiopian Yirgacheffe Arabica', 'Filtered Spring Water (93°C)'],
    origin: 'Gedeb, Yirgacheffe, Ethiopia',
    flavorProfile: ['Jasmine Blossom', 'Bergamot', 'Meyer Lemon', 'Honey Finish'],
    caffeineLevel: 'Medium',
    tasteProfile: 'Refreshing',
    isTrending: true,
  },
  {
    name: 'Sumatra Mandheling',
    description:
      'Full-bodied wet-hulled Indonesian roast with deep cedarwood warmth, dark cocoa richness, and lingering sweet spice.',
    image: '/assets/images/sumatra-mandheling.jpg',
    category: 'Single Origin',
    ingredients: ['100% Sumatra Mandheling Arabica', 'Hot Brewed Water'],
    origin: 'Aceh & North Sumatra, Indonesia',
    flavorProfile: ['Dark Cocoa', 'Cedar Spice', 'Molasses', 'Velvet Body'],
    caffeineLevel: 'High',
    tasteProfile: 'Strong',
    isTrending: false,
  },
  {
    name: 'Cold Brew Nitro',
    description:
      'Slow-steeped 18-hour single-origin cold brew infused with pressurized nitrogen for a cascading, creamy stout-like texture.',
    image: '/assets/images/cold-brew-nitro.jpg',
    category: 'Cold Brew',
    ingredients: ['Coarse-Ground Latin Blend', 'Cold Filtered Water', 'Food-Grade Nitrogen'],
    origin: 'Colombia & Guatemala Blend',
    flavorProfile: ['Toasted Almond', 'Dark Caramel', 'Silky Crema', 'Crisp Finish'],
    caffeineLevel: 'Very High',
    tasteProfile: 'Refreshing',
    isTrending: true,
  },
  {
    name: 'Vanilla Latte',
    description:
      'Double ristretto espresso folded into micro-textured whole milk and house-steeped Madagascar bourbon vanilla bean.',
    image: '/assets/images/vanilla-latte.jpg',
    category: 'Specialty Latte',
    ingredients: ['Double Espresso Shot', 'Steamed Milk', 'Madagascar Vanilla Bean Syrup'],
    origin: 'Brazil & Ethiopia Espresso Blend',
    flavorProfile: ['Madagascar Vanilla', 'Sweet Cream', 'Toasted Hazelnut'],
    caffeineLevel: 'Medium',
    tasteProfile: 'Sweet',
    isTrending: true,
  },
  {
    name: 'Mexican Chiapas',
    description:
      'Shade-grown organic mountain harvest offering gentle roasted almond notes, milk chocolate sweetness, and bright apple acidity.',
    image: '/assets/images/mexican-chiapas.jpg',
    category: 'Single Origin',
    ingredients: ['100% Organic Chiapas Arabica', 'Filtered Water'],
    origin: 'Sierra Madre de Chiapas, Mexico',
    flavorProfile: ['Milk Chocolate', 'Roasted Almond', 'Red Apple', 'Brown Sugar'],
    caffeineLevel: 'Medium',
    tasteProfile: 'Strong',
    isTrending: false,
  },
  {
    name: 'Cappuccino',
    description:
      'Traditional Italian balance of syrupy double espresso, steamed milk, and a dense, glossy cap of velvety microfoam.',
    image: '/assets/images/cappuccino.jpg',
    category: 'Espresso',
    ingredients: ['Double Espresso Shot', 'Steamed Milk', 'Microfoam'],
    origin: 'Northern Italian Espresso Blend',
    flavorProfile: ['Roasted Hazelnut', 'Cocoa Dust', 'Caramelized Milk'],
    caffeineLevel: 'Medium',
    tasteProfile: 'Creamy',
    isTrending: false,
  },
  {
    name: 'Caramel Macchiato',
    description:
      'Layered espresso poured over cold or steamed milk kissed with vanilla and finished with golden salted butter caramel.',
    image: '/assets/images/caramel-macchiato.jpg',
    category: 'Specialty Latte',
    ingredients: ['Double Espresso', 'Steamed Milk', 'Vanilla Bean', 'Salted Caramel Drizzle'],
    origin: 'Central American Espresso Blend',
    flavorProfile: ['Salted Caramel', 'Toasted Sugar', 'Velvet Espresso'],
    caffeineLevel: 'Medium',
    tasteProfile: 'Sweet',
    isTrending: true,
  },
  {
    name: 'Mocha',
    description:
      'Artisanal single-origin 70% dark chocolate ganache melted into hot espresso and crowned with silky steamed milk.',
    image: '/assets/images/mocha.jpg',
    category: 'Specialty Latte',
    ingredients: ['Double Espresso', '70% Dark Chocolate Ganache', 'Steamed Milk', 'Cocoa Shavings'],
    origin: 'Colombia Espresso & Ecuador Cacao',
    flavorProfile: ['Bittersweet Cocoa', 'Fudge', 'Roasted Espresso'],
    caffeineLevel: 'Medium',
    tasteProfile: 'Creamy',
    isTrending: false,
  },
  {
    name: 'Espresso',
    description:
      'Precision-pulled 9-bar double shot crowned with dense tiger-striped crema, offering intense bittersweet chocolate and citrus zest.',
    image: '/assets/images/espresso.jpg',
    category: 'Espresso',
    ingredients: ['18g Finely Ground Espresso Blend', '93°C Soft Water (9 Bar)'],
    origin: 'Brazil, Colombia & Ethiopia Blend',
    flavorProfile: ['Dark Chocolate', 'Blood Orange', 'Molasses Crema'],
    caffeineLevel: 'High',
    tasteProfile: 'Strong',
    isTrending: true,
  },
  {
    name: 'Matcha Latte',
    description:
      'First-harvest stone-ground Uji ceremonial matcha whisked to a jade crema and poured into silky steamed oat or dairy milk.',
    image: '/assets/images/matcha-latte.jpg',
    category: 'Tea Latte',
    ingredients: ['Ceremonial Uji Matcha', 'Steamed Milk', 'Light Cane Touch'],
    origin: 'Uji, Kyoto Prefecture, Japan',
    flavorProfile: ['Sweet Umami', 'Fresh Bamboo', 'Creamy Finish'],
    caffeineLevel: 'Low',
    tasteProfile: 'Creamy',
    isTrending: false,
  },
];

const DEMO_USERS = [
  { name: 'Elena Vance', email: 'barista@brewverse.com', password: 'Password123!' },
  { name: 'Marcus Thorne', email: 'marcus@brewverse.com', password: 'Password123!' },
  { name: 'Sora Takahashi', email: 'sora@brewverse.com', password: 'Password123!' },
  { name: 'Camila Reyes', email: 'camila@brewverse.com', password: 'Password123!' },
  { name: 'Liam OConnor', email: 'liam@brewverse.com', password: 'Password123!' },
  { name: 'Nadia Al-Mansoor', email: 'nadia@brewverse.com', password: 'Password123!' },
];

const INITIAL_REVIEWS = [
  {
    coffeeName: 'Ethiopian Yirgacheffe',
    userIdx: 1,
    rating: 5,
    comment: 'Incredible floral aroma as soon as it hits the cup. Crisp jasmine and citrus without any bitterness.',
  },
  {
    coffeeName: 'Ethiopian Yirgacheffe',
    userIdx: 2,
    rating: 5,
    comment: 'My daily pour-over benchmark. Clean, bright, and tea-like.',
  },
  {
    coffeeName: 'Cold Brew Nitro',
    userIdx: 3,
    rating: 5,
    comment: 'The nitrogen cascade makes it feel like a dessert without needing any sugar or cream.',
  },
  {
    coffeeName: 'Cold Brew Nitro',
    userIdx: 4,
    rating: 4,
    comment: 'Super smooth texture and serious caffeine lift for afternoon studio sessions.',
  },
  {
    coffeeName: 'Espresso',
    userIdx: 1,
    rating: 5,
    comment: 'Syrupy crema and rich bittersweet cocoa. Pulls cleanly every time.',
  },
  {
    coffeeName: 'Vanilla Latte',
    userIdx: 5,
    rating: 5,
    comment: 'Real vanilla bean specks make all the difference—balanced sweetness with zero artificial syrup aftertaste.',
  },
  {
    coffeeName: 'Caramel Macchiato',
    userIdx: 3,
    rating: 4,
    comment: 'Golden salted caramel pairs wonderfully with the bold espresso ribbon.',
  },
  {
    coffeeName: 'Cappuccino',
    userIdx: 2,
    rating: 5,
    comment: 'Textbook microfoam density and classic Italian warmth.',
  },
  {
    coffeeName: 'Sumatra Mandheling',
    userIdx: 4,
    rating: 4,
    comment: 'Earthy, deep, and comforting on rainy mornings.',
  },
  {
    coffeeName: 'Mexican Chiapas',
    userIdx: 5,
    rating: 4,
    comment: 'Gentle cocoa and toasted nut profile—very approachable single origin.',
  },
  {
    coffeeName: 'Mocha',
    userIdx: 1,
    rating: 5,
    comment: 'Rich dark chocolate ganache melts cleanly into the espresso.',
  },
  {
    coffeeName: 'Matcha Latte',
    userIdx: 2,
    rating: 5,
    comment: 'Vibrant Uji ceremonial grade with calm, sustained focus and creamy umami.',
  },
];

// Deterministic vote matrix referencing real User & Coffee documents
const VOTE_DISTRIBUTION = {
  'Ethiopian Yirgacheffe': [0, 1, 2, 3, 4, 5],
  'Cold Brew Nitro': [1, 2, 3, 4, 5],
  Espresso: [0, 1, 3, 4],
  'Vanilla Latte': [2, 3, 4, 5],
  'Caramel Macchiato': [1, 3, 5],
  Cappuccino: [1, 2, 4],
  Mocha: [2, 5],
  'Sumatra Mandheling': [1, 4],
  'Mexican Chiapas': [3, 5],
  'Matcha Latte': [2],
};

export async function seedDatabaseIfEmpty() {
  const existingCoffees = await Coffee.countDocuments();
  if (existingCoffees > 0) return;

  console.log('Seeding BREWVERSE initial coffee catalog, community votes, and reviews...');

  const createdUsers = [];
  for (const u of DEMO_USERS) {
    const user = await User.create(u);
    createdUsers.push(user);
  }

  const coffeeMap = new Map();
  for (const item of SAMPLE_COFFEES) {
    const coffee = await Coffee.create(item);
    coffeeMap.set(coffee.name, coffee);
  }

  // Create real Vote documents
  for (const [coffeeName, userIndices] of Object.entries(VOTE_DISTRIBUTION)) {
    const coffee = coffeeMap.get(coffeeName);
    if (!coffee) continue;

    for (const idx of userIndices) {
      const user = createdUsers[idx];
      if (!user) continue;
      await Vote.create({ userId: user._id, coffeeId: coffee._id });
    }
    coffee.totalVotes = userIndices.length;
    await coffee.save();
  }

  // Seed demo user favorites (for barista@brewverse.com)
  const demoUser = createdUsers[0];
  demoUser.favorites = [
    coffeeMap.get('Ethiopian Yirgacheffe')._id,
    coffeeMap.get('Espresso')._id,
  ];
  await demoUser.save();

  // Create real Review documents & calculate accurate averageRating
  for (const rev of INITIAL_REVIEWS) {
    const coffee = coffeeMap.get(rev.coffeeName);
    const user = createdUsers[rev.userIdx];
    if (!coffee || !user) continue;

    await Review.create({
      userId: user._id,
      coffeeId: coffee._id,
      rating: rev.rating,
      comment: rev.comment,
    });
  }

  // Recompute ratings accurately from Review collection
  for (const coffee of coffeeMap.values()) {
    const reviews = await Review.find({ coffeeId: coffee._id });
    if (reviews.length > 0) {
      const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
      coffee.averageRating = Number((sum / reviews.length).toFixed(2));
      coffee.reviewCount = reviews.length;
      await coffee.save();
    }
  }

  console.log('BREWVERSE seed completed cleanly.');
}
