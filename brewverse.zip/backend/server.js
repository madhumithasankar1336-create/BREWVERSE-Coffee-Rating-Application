import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import { connectDB } from './config/db.js';
import { seedDatabaseIfEmpty } from './data/seedCoffees.js';
import { createApiApp } from './app.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendDir = path.resolve(__dirname, '../frontend');

const PORT = Number(process.env.PORT) || 5000;

async function startServer() {
  try {
    await connectDB();
    await seedDatabaseIfEmpty();

    const app = createApiApp();
    app.use(express.static(frontendDir));

    app.get('*', (_req, res) => {
      res.sendFile(path.join(frontendDir, 'index.html'));
    });

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`BREWVERSE backend running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start BREWVERSE backend:', err);
    process.exit(1);
  }
}

startServer();
