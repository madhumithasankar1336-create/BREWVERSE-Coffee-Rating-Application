import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export function getJwtSecret() {
  return process.env.JWT_SECRET || 'brewverse_local_dev_jwt_secret_key';
}

export async function protect(req, res, next) {
  try {
    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required. Please sign in to continue.',
      });
    }

    const token = authHeader.slice(7).trim();
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication token.',
      });
    }

    const decoded = jwt.verify(token, getJwtSecret());
    const user = await User.findById(decoded.id);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User account no longer exists.',
      });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Session expired or invalid token. Please sign in again.',
    });
  }
}

export async function optionalAuth(req, _res, next) {
  try {
    const authHeader = req.headers.authorization || '';
    if (authHeader.startsWith('Bearer ')) {
      const token = authHeader.slice(7).trim();
      if (token) {
        const decoded = jwt.verify(token, getJwtSecret());
        const user = await User.findById(decoded.id);
        if (user) req.user = user;
      }
    }
  } catch {
    // Ignore invalid optional auth header
  }
  next();
}
