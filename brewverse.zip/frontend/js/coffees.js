import { apiFetch, escapeHtml, getStoredUser, getToken, showToast } from './auth.js';
import { icon } from './icons.js';
import { animateNumber, submitVote, toggleFavorite } from './voting.js';

export const state = {
  allCoffees: [],
  filteredCoffees: [],
  userVotedIds: new Set(),
  userFavoriteIds: new Set(),
  favoritesList: [],
  filters: {
    search: '',
    category: 'All',
    sort: 'popular',
    trendingOnly: false,
  },
  battlePair: [],
  battleVotedId: null,
  quizAnswers: {
    vibe: null,
    caffeine: null,
    texture: null,
  },
};

export function buildImageMarkup(src, alt, fallbackTitle) {
  const safeSrc = escapeHtml(src);
  const safeAlt = escapeHtml(alt);
  const safeTitle = escapeHtml(fallbackTitle || alt);
  return `
    <img src="${safeSrc}" alt="${safeAlt}" loading="lazy"
      onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" />
    <div class="coffee-img-fallback" style="display:none;">
      ${icon('coffee', { size: 32 })}
      <span style="font-size:0.85rem;font-weight:600;">${safeTitle}</span>
    </div>
  `;
}

export async function loadCollectionData() {
  const params = new URLSearchParams();
  if (state.filters.search.trim()) params.set('search', state.filters.search.trim());
  if (state.filters.category && state.filters.category !== 'All') {
    params.set('category', state.filters.category);
  }
  if (state.filters.sort) params.set('sort', state.filters.sort);
  if (state.filters.trendingOnly) params.set('trending', 'true');

  const query = params.toString() ? `?${params.toString()}` : '';
  const data = await apiFetch(`/api/coffees${query}`);

  state.filteredCoffees = data.coffees || [];
  if (Array.isArray(data.userVotedIds)) {
    state.userVotedIds = new Set(data.userVotedIds);
  }

  // Keep master unfiltered snapshot when fetching default view
  if (
    !state.filters.search &&
    state.filters.category === 'All' &&
    !state.filters.trendingOnly
  ) {
    state.allCoffees = [...state.filteredCoffees];
  } else if (state.allCoffees.length === 0) {
    const allRes = await apiFetch('/api/coffees');
    state.allCoffees = allRes.coffees || [];
  }

  if (getToken()) {
    try {
      const favRes = await apiFetch('/api/favorites');
      state.favoritesList = favRes.favorites || [];
      state.userFavoriteIds = new Set(state.favoritesList.map((c) => c._id));
    } catch {
      // Ignore if session expired
    }
  } else {
    state.favoritesList = [];
    state.userFavoriteIds = new Set();
    state.userVotedIds = new Set();
  }

  return data;
}

export function renderHeroStats() {
  const totalCoffeesEl = document.getElementById('stat-total-coffees');
  const totalVotesEl = document.getElementById('stat-total-votes');
  const topCoffeeEl = document.getElementById('stat-most-popular');

  const list = state.allCoffees;
  const totalVotes = list.reduce((acc, c) => acc + (c.totalVotes || 0), 0);
  const topCoffee = [...list].sort((a, b) => b.totalVotes - a.totalVotes)[0];

  animateNumber(totalCoffeesEl, list.length);
  animateNumber(totalVotesEl, totalVotes);
  if (topCoffeeEl) {
    topCoffeeEl.textContent = topCoffee ? topCoffee.name : '—';
  }
}

export async function renderFeaturedToday() {
  const container = document.getElementById('featured-cotd-container');
  if (!container) return;

  try {
    const res = await apiFetch('/api/coffees/featured/today');
    const c = res.coffee;
    if (!c) return;

    const isVoted = state.userVotedIds.has(c._id);
    container.innerHTML = `
      <div class="featured-cotd-media">
        ${buildImageMarkup(c.image, c.name, c.name)}
      </div>
      <div class="featured-cotd-meta">
        <span>Coffee of the Day</span>
        <span>${escapeHtml(c.category)} · ${escapeHtml(c.origin)}</span>
      </div>
      <div>
        <h2 class="featured-cotd-title">${escapeHtml(c.name)}</h2>
        <p class="featured-cotd-desc">${escapeHtml(c.description)}</p>
      </div>
      <div class="featured-cotd-actions">
        <div style="display:flex;align-items:center;gap:16px;font-size:0.88rem;">
          <span class="stat-pair">
            <span class="stat-star">${icon('star', { size: 15, filled: true })}</span>
            <strong class="tabular-nums">${Number(c.averageRating || 0).toFixed(1)}</strong>
          </span>
          <span class="stat-pair">
            ${icon('thumbUp', { size: 15 })}
            <strong class="tabular-nums" data-cotd-votes="${c._id}">${c.totalVotes}</strong> votes
          </span>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <button type="button" class="btn btn-sm ${isVoted ? 'btn-highlight' : 'btn-outline'}" data-vote-id="${c._id}">
            ${icon('thumbUp', { size: 14 })}
            <span>${isVoted ? 'Voted' : 'Vote'}</span>
          </button>
          <a href="/coffee-details.html?id=${c._id}" class="btn btn-primary btn-sm">Details</a>
        </div>
      </div>
    `;
  } catch {
    container.innerHTML = `<div class="empty-state">Unable to load Coffee of the Day.</div>`;
  }
}

export function renderTrendingStrip() {
  const container = document.getElementById('trending-grid');
  if (!container) return;

  const trending = state.allCoffees
    .filter((c) => c.isTrending)
    .sort((a, b) => b.totalVotes - a.totalVotes)
    .slice(0, 4);

  if (trending.length === 0) {
    container.innerHTML = `<div class="empty-state">No trending coffees right now.</div>`;
    return;
  }

  container.innerHTML = trending
    .map(
      (c) => `
      <a href="/coffee-details.html?id=${c._id}" class="glass-card trending-mini-card">
        <img class="trending-thumb" src="${escapeHtml(c.image)}" alt="${escapeHtml(c.name)}" />
        <div class="trending-info">
          <div class="trending-name">${escapeHtml(c.name)}</div>
          <div class="trending-sub">${escapeHtml(c.category)} · <span class="tabular-nums">${c.totalVotes}</span> votes</div>
        </div>
      </a>
    `
    )
    .join('');
}

export function renderCoffeeGrid() {
  const grid = document.getElementById('coffee-grid');
  const countLabel = document.getElementById('collection-count-label');
  if (!grid) return;

  if (countLabel) {
    countLabel.textContent = `${state.filteredCoffees.length} ${
      state.filteredCoffees.length === 1 ? 'variety' : 'varieties'
    } shown`;
  }

  if (state.filteredCoffees.length === 0) {
    grid.innerHTML = `
      <div class="glass-card empty-state" style="grid-column:1/-1;">
        <h3 class="font-display" style="font-size:1.3rem;margin-bottom:8px;">No matching coffees found</h3>
        <p style="margin-bottom:16px;">Try clearing your search term or switching category filters.</p>
        <button type="button" id="reset-filters-btn" class="btn btn-outline btn-sm">Reset Filters</button>
      </div>
    `;
    const resetBtn = document.getElementById('reset-filters-btn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        state.filters = { search: '', category: 'All', sort: 'popular', trendingOnly: false };
        syncFilterControls();
        refreshCollection();
      });
    }
    return;
  }

  grid.innerHTML = state.filteredCoffees
    .map((coffee) => {
      const isVoted = state.userVotedIds.has(coffee._id);
      const isFav = state.userFavoriteIds.has(coffee._id);

      return `
        <article class="glass-card coffee-card" data-coffee-id="${coffee._id}">
          <div class="coffee-card-media">
            ${buildImageMarkup(coffee.image, coffee.name, coffee.name)}
            <button
              type="button"
              class="fav-float-btn ${isFav ? 'favorited' : ''}"
              data-fav-id="${coffee._id}"
              aria-label="${isFav ? 'Remove from favorites' : 'Save to favorites'}"
              title="${isFav ? 'Remove from favorites' : 'Save to favorites'}"
            >
              ${icon('heart', { size: 17, filled: isFav })}
            </button>
          </div>
          <div class="coffee-card-body">
            <div class="coffee-meta-line">
              <span>${escapeHtml(coffee.category)}</span>
              <span aria-hidden="true">·</span>
              <span>${escapeHtml(coffee.origin)}</span>
            </div>
            <h3 class="coffee-card-title">${escapeHtml(coffee.name)}</h3>
            <p class="coffee-card-desc">${escapeHtml(coffee.description)}</p>
            <div class="coffee-stats-row">
              <span class="stat-pair">
                ${icon('thumbUp', { size: 15 })}
                <strong class="tabular-nums" data-vote-count="${coffee._id}">${coffee.totalVotes}</strong>
                <span>votes</span>
              </span>
              <span class="stat-pair">
                <span class="stat-star">${icon('star', { size: 15, filled: true })}</span>
                <strong class="tabular-nums">${Number(coffee.averageRating || 0).toFixed(1)}</strong>
                <span>(${coffee.reviewCount || 0})</span>
              </span>
            </div>
            <div class="coffee-card-actions">
              <button
                type="button"
                class="btn btn-sm vote-btn ${isVoted ? 'voted' : 'btn-primary'}"
                data-vote-id="${coffee._id}"
              >
                ${icon('thumbUp', { size: 15 })}
                <span>${isVoted ? 'Voted' : 'Vote'}</span>
              </button>
              <a href="/coffee-details.html?id=${coffee._id}" class="btn btn-outline btn-sm">
                View Details
              </a>
            </div>
          </div>
        </article>
      `;
    })
    .join('');
}

export function renderFavoritesSection() {
  const container = document.getElementById('favorites-section-body');
  if (!container) return;

  const user = getStoredUser();
  if (!user) {
    container.innerHTML = `
      <div class="glass-card empty-state">
        <p style="margin-bottom:14px;">Sign in to save your favorite coffees and access your tasting shelf anywhere.</p>
        <a href="/login.html" class="btn btn-primary btn-sm">Sign In to View Favorites</a>
      </div>
    `;
    return;
  }

  if (state.favoritesList.length === 0) {
    container.innerHTML = `
      <div class="glass-card empty-state">
        <p>You have not saved any favorite coffees yet. Tap the heart button on any brew card to add it here.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="favorites-grid">
      ${state.favoritesList
        .map(
          (c) => `
        <div class="glass-card" style="padding:16px;display:flex;align-items:center;gap:14px;">
          <img src="${escapeHtml(c.image)}" alt="${escapeHtml(c.name)}" style="width:74px;height:74px;border-radius:10px;object-fit:cover;flex-shrink:0;" />
          <div style="min-width:0;flex:1;">
            <div style="font-size:0.78rem;color:var(--text-muted);">${escapeHtml(c.category)}</div>
            <a href="/coffee-details.html?id=${c._id}" class="font-display" style="font-size:1.08rem;font-weight:600;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(c.name)}</a>
            <div style="font-size:0.82rem;color:var(--text-secondary);margin-top:2px;">
              <span class="tabular-nums">${c.totalVotes}</span> votes · ${Number(c.averageRating || 0).toFixed(1)} stars
            </div>
          </div>
          <button type="button" class="icon-btn" data-fav-id="${c._id}" aria-label="Remove from favorites" title="Remove">
            ${icon('close', { size: 16 })}
          </button>
        </div>
      `
        )
        .join('')}
    </div>
  `;
}

export function pickBattlePair() {
  if (state.allCoffees.length < 2) return;
  const pool = [...state.allCoffees];
  const idxA = Math.floor(Math.random() * pool.length);
  const first = pool.splice(idxA, 1)[0];
  const idxB = Math.floor(Math.random() * pool.length);
  const second = pool[idxB];
  state.battlePair = [first, second];
  state.battleVotedId = null;
  renderBattleArena();
}

export function renderBattleArena() {
  const container = document.getElementById('battle-arena-body');
  if (!container) return;

  if (state.battlePair.length < 2) {
    container.innerHTML = `<div class="empty-state">Loading Coffee Battle contenders...</div>`;
    return;
  }

  // Always read latest vote counts from state.allCoffees
  const left = state.allCoffees.find((c) => c._id === state.battlePair[0]._id) || state.battlePair[0];
  const right = state.allCoffees.find((c) => c._id === state.battlePair[1]._id) || state.battlePair[1];

  const total = (left.totalVotes || 0) + (right.totalVotes || 0);
  const leftPct = total > 0 ? Math.round((left.totalVotes / total) * 100) : 50;
  const rightPct = total > 0 ? 100 - leftPct : 50;
  const leftWins = left.totalVotes >= right.totalVotes;

  container.innerHTML = `
    <div class="battle-grid">
      <div class="battle-contender ${state.battleVotedId && leftWins ? 'winner' : ''}">
        <img src="${escapeHtml(left.image)}" alt="${escapeHtml(left.name)}" />
        <div class="coffee-meta-line">
          <span>${escapeHtml(left.category)}</span>
          <span aria-hidden="true">·</span>
          <span>${escapeHtml(left.origin)}</span>
        </div>
        <h3 class="font-display" style="font-size:1.35rem;">${escapeHtml(left.name)}</h3>
        <p style="font-size:0.88rem;color:var(--text-secondary);">${escapeHtml(left.description)}</p>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:8px;">
          <span class="tabular-nums" style="font-weight:600;">${left.totalVotes} votes</span>
          <button type="button" class="btn btn-primary btn-sm" data-battle-vote="${left._id}" data-battle-other="${right._id}">
            ${icon('thumbUp', { size: 14 })}
            <span>Vote ${escapeHtml(left.name.split(' ')[0])}</span>
          </button>
        </div>
      </div>

      <div class="battle-vs">VS</div>

      <div class="battle-contender ${state.battleVotedId && !leftWins ? 'winner' : ''}">
        <img src="${escapeHtml(right.image)}" alt="${escapeHtml(right.name)}" />
        <div class="coffee-meta-line">
          <span>${escapeHtml(right.category)}</span>
          <span aria-hidden="true">·</span>
          <span>${escapeHtml(right.origin)}</span>
        </div>
        <h3 class="font-display" style="font-size:1.35rem;">${escapeHtml(right.name)}</h3>
        <p style="font-size:0.88rem;color:var(--text-secondary);">${escapeHtml(right.description)}</p>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:8px;">
          <span class="tabular-nums" style="font-weight:600;">${right.totalVotes} votes</span>
          <button type="button" class="btn btn-highlight btn-sm" data-battle-vote="${right._id}" data-battle-other="${left._id}">
            ${icon('thumbUp', { size: 14 })}
            <span>Vote ${escapeHtml(right.name.split(' ')[0])}</span>
          </button>
        </div>
      </div>
    </div>

    <div class="battle-result-bar">
      <div class="battle-progress-track">
        <div class="battle-progress-left" style="width:${leftPct}%;"></div>
        <div class="battle-progress-right" style="width:${rightPct}%;"></div>
      </div>
      <div class="battle-progress-labels">
        <span><strong>${escapeHtml(left.name)}</strong> (${leftPct}%)</span>
        <span>${left.totalVotes === right.totalVotes ? 'Tied Matchup' : `Current Leader: ${escapeHtml(leftWins ? left.name : right.name)}`}</span>
        <span><strong>${escapeHtml(right.name)}</strong> (${rightPct}%)</span>
      </div>
    </div>
  `;
}

export function computeQuizRecommendation() {
  const { vibe, caffeine, texture } = state.quizAnswers;
  if (!vibe) return null;

  const pool = state.allCoffees;
  if (pool.length === 0) return null;

  const scored = pool.map((c) => {
    let score = 0;
    if (c.tasteProfile === vibe) score += 5;
    if (caffeine && c.caffeineLevel === caffeine) score += 3;
    if (texture === 'Milk' && (c.category === 'Specialty Latte' || c.category === 'Tea Latte' || c.name === 'Cappuccino')) {
      score += 2;
    }
    if (texture === 'Black' && (c.category === 'Single Origin' || c.category === 'Cold Brew' || c.name === 'Espresso')) {
      score += 2;
    }
    score += (c.averageRating || 0) * 0.2;
    return { coffee: c, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0].coffee;
}

export function renderQuizRecommendation() {
  const resultEl = document.getElementById('quiz-result-card');
  if (!resultEl) return;

  const rec = computeQuizRecommendation();
  if (!rec) {
    resultEl.innerHTML = `
      <div class="empty-state" style="margin:auto;">
        <div style="margin-bottom:10px;color:var(--brand-secondary);">${icon('coffee', { size: 32 })}</div>
        <h3 class="font-display" style="font-size:1.3rem;margin-bottom:8px;">Your Personalized Cup</h3>
        <p style="font-size:0.9rem;">Select your taste mood on the left to reveal your ideal coffee match.</p>
      </div>
    `;
    return;
  }

  const isVoted = state.userVotedIds.has(rec._id);
  resultEl.innerHTML = `
    <img src="${escapeHtml(rec.image)}" alt="${escapeHtml(rec.name)}" />
    <div>
      <div class="coffee-meta-line" style="margin-bottom:4px;">
        <span>Recommended Match</span>
        <span aria-hidden="true">·</span>
        <span>${escapeHtml(rec.tasteProfile)} Profile</span>
      </div>
      <h3 class="font-display" style="font-size:1.5rem;margin-bottom:6px;">${escapeHtml(rec.name)}</h3>
      <p style="font-size:0.9rem;color:var(--text-secondary);margin-bottom:14px;">${escapeHtml(rec.description)}</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button type="button" class="btn btn-sm ${isVoted ? 'btn-highlight' : 'btn-primary'}" data-vote-id="${rec._id}">
          ${icon('thumbUp', { size: 14 })}
          <span>${isVoted ? 'Voted' : 'Vote for Match'}</span>
        </button>
        <a href="/coffee-details.html?id=${rec._id}" class="btn btn-outline btn-sm">Explore Details</a>
      </div>
    </div>
  `;
}

export async function triggerSurpriseCoffee() {
  const modal = document.getElementById('surprise-modal');
  const body = document.getElementById('surprise-modal-body');
  if (!modal || !body) return;

  modal.classList.add('open');
  body.innerHTML = `<div class="empty-state">Brewing a surprise recommendation...</div>`;

  try {
    const res = await apiFetch('/api/coffees/random');
    const c = res.coffee;
    body.innerHTML = `
      <img src="${escapeHtml(c.image)}" alt="${escapeHtml(c.name)}" style="width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:14px;margin-bottom:16px;" />
      <div class="coffee-meta-line" style="margin-bottom:4px;">
        <span>${escapeHtml(c.category)}</span>
        <span aria-hidden="true">·</span>
        <span>${escapeHtml(c.origin)}</span>
      </div>
      <h3 class="font-display" style="font-size:1.55rem;margin-bottom:8px;">${escapeHtml(c.name)}</h3>
      <p style="font-size:0.92rem;color:var(--text-secondary);margin-bottom:18px;">${escapeHtml(c.description)}</p>
      <div style="display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap;">
        <button type="button" class="btn btn-outline btn-sm" id="surprise-again-btn">
          ${icon('shuffle', { size: 14 })}
          <span>Spin Again</span>
        </button>
        <a href="/coffee-details.html?id=${c._id}" class="btn btn-primary btn-sm">View Coffee</a>
      </div>
    `;
    body.querySelector('#surprise-again-btn')?.addEventListener('click', triggerSurpriseCoffee);
  } catch (err) {
    body.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
  }
}

export function syncFilterControls() {
  const searchInput = document.getElementById('coffee-search-input');
  const sortSelect = document.getElementById('coffee-sort-select');
  const trendingBtn = document.getElementById('trending-filter-btn');
  const catButtons = document.querySelectorAll('[data-category-tab]');

  if (searchInput) searchInput.value = state.filters.search;
  if (sortSelect) sortSelect.value = state.filters.sort;
  if (trendingBtn) trendingBtn.classList.toggle('active', state.filters.trendingOnly);
  catButtons.forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.categoryTab === state.filters.category);
  });
}

export async function refreshCollection() {
  const grid = document.getElementById('coffee-grid');
  if (grid && state.filteredCoffees.length === 0) {
    grid.innerHTML = Array.from({ length: 6 })
      .map(
        () => `
        <div class="glass-card" style="padding:18px;">
          <div class="skeleton" style="aspect-ratio:4/3;margin-bottom:14px;"></div>
          <div class="skeleton" style="height:22px;width:65%;margin-bottom:10px;"></div>
          <div class="skeleton" style="height:36px;width:100%;"></div>
        </div>
      `
      )
      .join('');
  }

  try {
    await loadCollectionData();
    renderHeroStats();
    await renderFeaturedToday();
    renderTrendingStrip();
    renderCoffeeGrid();
    renderFavoritesSection();
    if (state.battlePair.length < 2) {
      pickBattlePair();
    } else {
      renderBattleArena();
    }
    renderQuizRecommendation();
  } catch (err) {
    showToast(err.message || 'Failed to load coffee data.', 'error');
  }
}

export function bindCollectionEvents() {
  // Delegated click handler for Vote, Favorite, Battle Vote
  document.addEventListener('click', async (e) => {
    const voteBtn = e.target.closest('[data-vote-id]');
    if (voteBtn) {
      const coffeeId = voteBtn.dataset.voteId;
      voteBtn.disabled = true;
      const result = await submitVote(coffeeId);
      voteBtn.disabled = false;
      if (result) {
        state.userVotedIds = new Set(result.userVotedIds || []);
        const updateItem = (item) => {
          if (item._id === coffeeId) item.totalVotes = result.totalVotes;
        };
        state.allCoffees.forEach(updateItem);
        state.filteredCoffees.forEach(updateItem);

        // Animate count and button feedback
        document.querySelectorAll(`[data-vote-count="${coffeeId}"], [data-cotd-votes="${coffeeId}"]`).forEach((el) => {
          animateNumber(el, result.totalVotes);
        });
        voteBtn.classList.add('pulse-pop');
        await refreshCollection();
      }
      return;
    }

    const battleBtn = e.target.closest('[data-battle-vote]');
    if (battleBtn) {
      const winnerId = battleBtn.dataset.battleVote;
      const otherId = battleBtn.dataset.battleOther;
      battleBtn.disabled = true;
      const switchFrom = state.userVotedIds.has(otherId) ? otherId : null;
      const result = await submitVote(winnerId, {
        switchFromCoffeeId: switchFrom,
        action: 'add',
      });
      battleBtn.disabled = false;
      if (result) {
        state.battleVotedId = winnerId;
        state.userVotedIds = new Set(result.userVotedIds || []);
        await refreshCollection();
      } else {
        // Also allow checking if user already voted for this contender
        renderBattleArena();
      }
      return;
    }

    const favBtn = e.target.closest('[data-fav-id]');
    if (favBtn) {
      const coffeeId = favBtn.dataset.favId;
      const isCurrentlyFav = state.userFavoriteIds.has(coffeeId);
      favBtn.disabled = true;
      const res = await toggleFavorite(coffeeId, isCurrentlyFav);
      favBtn.disabled = false;
      if (res) {
        state.favoritesList = res.favorites || [];
        state.userFavoriteIds = new Set(state.favoritesList.map((c) => c._id));
        renderCoffeeGrid();
        renderFavoritesSection();
      }
    }
  });

  // Search & filter controls
  const searchInput = document.getElementById('coffee-search-input');
  if (searchInput) {
    let timer = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        state.filters.search = searchInput.value;
        refreshCollection();
      }, 220);
    });
  }

  document.querySelectorAll('[data-category-tab]').forEach((tab) => {
    tab.addEventListener('click', () => {
      state.filters.category = tab.dataset.categoryTab;
      syncFilterControls();
      refreshCollection();
    });
  });

  const sortSelect = document.getElementById('coffee-sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', () => {
      state.filters.sort = sortSelect.value;
      refreshCollection();
    });
  }

  const trendingBtn = document.getElementById('trending-filter-btn');
  if (trendingBtn) {
    trendingBtn.addEventListener('click', () => {
      state.filters.trendingOnly = !state.filters.trendingOnly;
      syncFilterControls();
      refreshCollection();
    });
  }

  const nextBattleBtn = document.getElementById('next-battle-btn');
  if (nextBattleBtn) {
    nextBattleBtn.addEventListener('click', pickBattlePair);
  }

  const surpriseBtn = document.getElementById('surprise-coffee-btn');
  if (surpriseBtn) {
    surpriseBtn.addEventListener('click', triggerSurpriseCoffee);
  }

  const closeSurpriseBtn = document.getElementById('close-surprise-modal');
  const surpriseModal = document.getElementById('surprise-modal');
  if (closeSurpriseBtn && surpriseModal) {
    closeSurpriseBtn.addEventListener('click', () => surpriseModal.classList.remove('open'));
    surpriseModal.addEventListener('click', (e) => {
      if (e.target === surpriseModal) surpriseModal.classList.remove('open');
    });
  }

  // Personality Quiz buttons
  document.querySelectorAll('[data-quiz-group]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const group = btn.dataset.quizGroup;
      const val = btn.dataset.quizValue;
      state.quizAnswers[group] = val;

      document.querySelectorAll(`[data-quiz-group="${group}"]`).forEach((sibling) => {
        sibling.classList.toggle('selected', sibling === btn);
      });
      renderQuizRecommendation();
    });
  });

  window.addEventListener('brewverse:auth-changed', () => {
    refreshCollection();
  });
}
