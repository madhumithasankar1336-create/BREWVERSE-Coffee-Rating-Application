import { apiFetch, getToken, requireAuthPrompt, showToast } from './auth.js';

export function animateNumber(element, targetValue, duration = 420) {
  if (!element) return;
  const startValue = Number(element.dataset.value || element.textContent.replace(/[^\d]/g, '') || 0);
  const endValue = Number(targetValue) || 0;
  element.dataset.value = String(endValue);

  if (startValue === endValue) {
    element.textContent = endValue.toLocaleString();
    return;
  }

  const startTime = performance.now();
  function tick(now) {
    const progress = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.round(startValue + (endValue - startValue) * eased);
    element.textContent = current.toLocaleString();
    if (progress < 1) {
      requestAnimationFrame(tick);
    } else {
      element.textContent = endValue.toLocaleString();
    }
  }
  requestAnimationFrame(tick);
}

export async function submitVote(coffeeId, { switchFromCoffeeId = null, action = null } = {}) {
  if (!getToken()) {
    requireAuthPrompt('cast your vote');
    return null;
  }

  const payload = { coffeeId };
  if (switchFromCoffeeId) payload.switchFromCoffeeId = switchFromCoffeeId;
  if (action) payload.action = action;

  try {
    const res = await apiFetch('/api/votes', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    showToast(res.message);
    return res;
  } catch (err) {
    showToast(err.message || 'Unable to submit vote.', 'error');
    return null;
  }
}

export async function toggleFavorite(coffeeId, isCurrentlyFavorited) {
  if (!getToken()) {
    requireAuthPrompt('save favorite coffees');
    return null;
  }

  try {
    if (isCurrentlyFavorited) {
      const res = await apiFetch(`/api/favorites/${coffeeId}`, { method: 'DELETE' });
      showToast(res.message);
      return res;
    }
    const res = await apiFetch('/api/favorites', {
      method: 'POST',
      body: JSON.stringify({ coffeeId }),
    });
    showToast(res.message);
    return res;
  } catch (err) {
    showToast(err.message || 'Unable to update favorites.', 'error');
    return null;
  }
}
