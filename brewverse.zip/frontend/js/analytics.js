import { apiFetch, escapeHtml, showToast } from './auth.js';
import { icon } from './icons.js';
import { animateNumber } from './voting.js';

let latestAnalyticsData = null;

function getChartPalette() {
  const isDark = document.documentElement.classList.contains('dark');
  return {
    text: isDark ? '#dccab8' : '#5c4235',
    grid: isDark ? 'rgba(245, 185, 66, 0.12)' : 'rgba(59, 36, 24, 0.1)',
    bars: ['#3b2418', '#c68b59', '#f5b942', '#7a4b32', '#9c6644'],
    barsDark: ['#f5b942', '#d99d6a', '#b87643', '#8c5432', '#e8c589'],
    isDark,
  };
}

function drawDistributionChart(canvas, distribution) {
  if (!canvas || !distribution || distribution.length === 0) return;
  const ctx = canvas.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const width = canvas.parentElement.clientWidth;
  const height = 320;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  ctx.scale(dpr, dpr);

  const palette = getChartPalette();
  ctx.clearRect(0, 0, width, height);

  const padLeft = 44;
  const padRight = 18;
  const padTop = 20;
  const padBottom = 86;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const maxVotes = Math.max(...distribution.map((d) => d.totalVotes), 1);
  const ticks = 4;

  ctx.font = '500 11px "JetBrains Mono", monospace';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';

  for (let i = 0; i <= ticks; i += 1) {
    const val = Math.round((maxVotes / ticks) * i);
    const y = padTop + plotH - (plotH / ticks) * i;
    ctx.strokeStyle = palette.grid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padLeft, y);
    ctx.lineTo(width - padRight, y);
    ctx.stroke();

    ctx.fillStyle = palette.text;
    ctx.fillText(String(val), padLeft - 8, y);
  }

  const barCount = distribution.length;
  const slotW = plotW / barCount;
  const barW = Math.min(38, slotW * 0.58);
  const colors = palette.isDark ? palette.barsDark : palette.bars;

  distribution.forEach((item, idx) => {
    const x = padLeft + idx * slotW + (slotW - barW) / 2;
    const barH = (item.totalVotes / maxVotes) * plotH;
    const y = padTop + plotH - barH;

    ctx.fillStyle = colors[idx % colors.length];
    const r = Math.min(6, barW / 2, barH);
    ctx.beginPath();
    ctx.moveTo(x, padTop + plotH);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.lineTo(x + barW - r, y);
    ctx.quadraticCurveTo(x + barW, y, x + barW, y + r);
    ctx.lineTo(x + barW, padTop + plotH);
    ctx.closePath();
    ctx.fill();

    // Value label above bar
    ctx.fillStyle = palette.text;
    ctx.textAlign = 'center';
    ctx.font = '600 11px "JetBrains Mono", monospace';
    ctx.fillText(String(item.totalVotes), x + barW / 2, y - 10);

    // Rotated coffee label
    ctx.save();
    ctx.translate(x + barW / 2, padTop + plotH + 12);
    ctx.rotate(-0.48);
    ctx.textAlign = 'right';
    ctx.font = '500 11px "Plus Jakarta Sans", sans-serif';
    const shortName = item.name.length > 15 ? `${item.name.slice(0, 14)}…` : item.name;
    ctx.fillText(shortName, 0, 0);
    ctx.restore();
  });
}

function drawCategoryDonutChart(canvas, categories) {
  if (!canvas || !categories || categories.length === 0) return;
  const ctx = canvas.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const width = canvas.parentElement.clientWidth;
  const height = 320;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  ctx.scale(dpr, dpr);

  const palette = getChartPalette();
  ctx.clearRect(0, 0, width, height);

  const total = Math.max(
    categories.reduce((acc, c) => acc + c.votes, 0),
    1
  );
  const cx = width / 2;
  const cy = 112;
  const radius = 78;
  const innerR = 46;
  const colors = palette.isDark ? palette.barsDark : palette.bars;

  let startAngle = -Math.PI / 2;
  categories.forEach((cat, idx) => {
    const slice = (cat.votes / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, startAngle, startAngle + slice);
    ctx.arc(cx, cy, innerR, startAngle + slice, startAngle, true);
    ctx.closePath();
    ctx.fillStyle = colors[idx % colors.length];
    ctx.fill();
    startAngle += slice;
  });

  // Center total
  ctx.fillStyle = palette.text;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '700 18px "JetBrains Mono", monospace';
  ctx.fillText(String(total), cx, cy - 6);
  ctx.font = '500 11px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('Total Votes', cx, cy + 12);

  // Legend below donut
  const legendStartY = 216;
  categories.forEach((cat, idx) => {
    const y = legendStartY + idx * 20;
    ctx.fillStyle = colors[idx % colors.length];
    ctx.fillRect(16, y - 5, 10, 10);

    ctx.fillStyle = palette.text;
    ctx.textAlign = 'left';
    ctx.font = '500 12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(cat.category, 34, y);

    ctx.textAlign = 'right';
    ctx.font = '600 12px "JetBrains Mono", monospace';
    const pct = Math.round((cat.votes / total) * 100);
    ctx.fillText(`${cat.votes} (${pct}%)`, width - 16, y);
  });
}

export async function loadLeaderboardAndAnalytics() {
  const leaderboardList = document.getElementById('leaderboard-list');
  try {
    const [leaderRes, analyticsRes] = await Promise.all([
      apiFetch('/api/leaderboard'),
      apiFetch('/api/analytics'),
    ]);

    latestAnalyticsData = analyticsRes;

    // Render Top 5 Leaderboard
    if (leaderboardList) {
      const items = leaderRes.leaderboard || [];
      if (items.length === 0) {
        leaderboardList.innerHTML = `<div class="glass-card empty-state">No votes recorded yet.</div>`;
      } else {
        leaderboardList.innerHTML = items
          .map(
            (item) => `
          <a href="/coffee-details.html?id=${item._id}" class="glass-card leader-row ${
              item.rank === 1 ? 'rank-one' : ''
            }">
            <div class="rank-num tabular-nums">#${item.rank}</div>
            <img class="leader-thumb" src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}" />
            <div>
              <div style="display:flex;align-items:center;gap:8px;">
                <span class="font-display" style="font-size:1.22rem;font-weight:600;">${escapeHtml(
                  item.name
                )}</span>
                ${
                  item.rank === 1
                    ? `<span style="color:var(--brand-highlight);display:inline-flex;" title="Top Voted">${icon(
                        'trophy',
                        { size: 17 }
                      )}</span>`
                    : ''
                }
              </div>
              <div style="font-size:0.82rem;color:var(--text-muted);">${escapeHtml(
                item.category
              )} · ${escapeHtml(item.origin)}</div>
            </div>
            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;color:var(--text-secondary);">
                <span>Vote Share</span>
                <strong class="tabular-nums">${item.percentage}%</strong>
              </div>
              <div class="bar-track">
                <div class="bar-fill" style="width:${item.percentage}%;"></div>
              </div>
            </div>
            <div style="text-align:right;">
              <div class="tabular-nums" style="font-size:1.15rem;font-weight:700;">${item.totalVotes}</div>
              <div style="font-size:0.78rem;color:var(--text-muted);">votes · ${Number(
                item.averageRating || 0
              ).toFixed(1)}★</div>
            </div>
          </a>
        `
          )
          .join('');
      }
    }

    // Render Analytics KPI Cards
    const s = analyticsRes.summary || {};
    animateNumber(document.getElementById('kpi-total-votes'), s.totalVotes || 0);
    animateNumber(document.getElementById('kpi-total-varieties'), s.totalVarieties || 0);

    const setKpi = (id, coffee, metricText) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.innerHTML = coffee
        ? `<div class="kpi-value" style="font-size:1.3rem;">${escapeHtml(
            coffee.name
          )}</div><div class="kpi-sub">${escapeHtml(metricText)}</div>`
        : '<div class="kpi-value">—</div>';
    };

    setKpi(
      'kpi-most-popular',
      s.mostPopular,
      s.mostPopular ? `${s.mostPopular.totalVotes} community votes` : ''
    );
    setKpi(
      'kpi-least-popular',
      s.leastPopular,
      s.leastPopular ? `${s.leastPopular.totalVotes} community votes` : ''
    );
    setKpi(
      'kpi-highest-rated',
      s.highestRated,
      s.highestRated ? `${Number(s.highestRated.averageRating).toFixed(2)} / 5.0 rating` : ''
    );

    renderCharts();
  } catch (err) {
    showToast(err.message || 'Unable to load analytics.', 'error');
  }
}

export function renderCharts() {
  if (!latestAnalyticsData) return;
  drawDistributionChart(
    document.getElementById('votes-distribution-chart'),
    latestAnalyticsData.distribution
  );
  drawCategoryDonutChart(
    document.getElementById('category-share-chart'),
    latestAnalyticsData.categoryBreakdown
  );
}
