import {
  apiFetch,
  clearSession,
  escapeHtml,
  getStoredUser,
  getToken,
  initHeaderChrome,
  refreshSessionIfNeeded,
  requireAuthPrompt,
  saveSession,
  showToast,
} from './auth.js';
import { icon } from './icons.js';
import {
  bindCollectionEvents,
  buildImageMarkup,
  refreshCollection,
} from './coffees.js';
import { loadLeaderboardAndAnalytics, renderCharts } from './analytics.js';
import { animateNumber, submitVote, toggleFavorite } from './voting.js';

async function initHomePage() {
  bindCollectionEvents();
  await refreshSessionIfNeeded();
  await refreshCollection();
}

async function initCoffeeDetailsPage() {
  await refreshSessionIfNeeded();
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const root = document.getElementById('coffee-details-root');
  if (!root) return;

  if (!id) {
    root.innerHTML = `<div class="glass-card empty-state">No coffee selected. <a href="/" style="text-decoration:underline;">Return to collection</a></div>`;
    return;
  }

  let selectedRating = 5;
  let currentFavIds = new Set();

  if (getToken()) {
    try {
      const favRes = await apiFetch('/api/favorites');
      currentFavIds = new Set((favRes.favorites || []).map((c) => c._id));
    } catch {
      // ignore
    }
  }

  async function renderDetails() {
    try {
      const res = await apiFetch(`/api/coffees/${id}`);
      const c = res.coffee;
      const reviews = res.reviews || [];
      const hasVoted = Boolean(res.hasVoted);
      const isFav = currentFavIds.has(c._id);

      document.title = `${c.name} — BREWVERSE`;

      root.innerHTML = `
        <div class="details-layout">
          <div class="details-image-frame glass-card">
            ${buildImageMarkup(c.image, c.name, c.name)}
          </div>

          <div class="glass-card details-info-card">
            <div class="coffee-meta-line">
              <span>${escapeHtml(c.category)}</span>
              <span aria-hidden="true">·</span>
              <span>${escapeHtml(c.origin)}</span>
            </div>
            <h1 class="font-display" style="font-size:clamp(1.9rem,3vw,2.5rem);">${escapeHtml(c.name)}</h1>
            <p style="color:var(--text-secondary);font-size:0.98rem;">${escapeHtml(c.description)}</p>

            <div class="spec-grid">
              <div>
                <div class="spec-item-label">Community Votes</div>
                <div class="spec-item-value tabular-nums" id="details-vote-count">${c.totalVotes}</div>
              </div>
              <div>
                <div class="spec-item-label">Average Rating</div>
                <div class="spec-item-value tabular-nums" id="details-avg-rating">${Number(c.averageRating || 0).toFixed(2)} / 5.0 (${c.reviewCount || 0})</div>
              </div>
              <div>
                <div class="spec-item-label">Caffeine Level</div>
                <div class="spec-item-value">${escapeHtml(c.caffeineLevel)}</div>
              </div>
              <div>
                <div class="spec-item-label">Flavor Profile</div>
                <div class="spec-item-value">${escapeHtml((c.flavorProfile || []).join(', ') || c.tasteProfile)}</div>
              </div>
            </div>

            <div>
              <h2 class="font-display" style="font-size:1.15rem;margin-bottom:8px;">Ingredients</h2>
              <ul class="ingredients-list">
                ${(c.ingredients || []).map((ing) => `<li>${escapeHtml(ing)}</li>`).join('')}
              </ul>
            </div>

            <div style="display:flex;gap:12px;flex-wrap:wrap;padding-top:8px;">
              <button type="button" id="details-vote-btn" class="btn ${hasVoted ? 'btn-highlight' : 'btn-primary'}">
                ${icon('thumbUp', { size: 16 })}
                <span>${hasVoted ? 'Voted (Click to Remove)' : 'Vote for This Coffee'}</span>
              </button>
              <button type="button" id="details-fav-btn" class="btn btn-outline">
                ${icon('heart', { size: 16, filled: isFav })}
                <span>${isFav ? 'Saved in Favorites' : 'Add to Favorites'}</span>
              </button>
            </div>
          </div>
        </div>

        <div class="reviews-layout">
          <div class="glass-card review-form-card">
            <h2 class="font-display" style="font-size:1.4rem;margin-bottom:8px;">Share Your Tasting Note</h2>
            <p style="font-size:0.88rem;color:var(--text-secondary);margin-bottom:18px;">Rate this brew and leave tasting feedback for the community.</p>
            <form id="review-submit-form" novalidate>
              <div class="form-group">
                <label class="form-label">Your Rating</label>
                <div class="star-picker" id="star-picker">
                  ${[1, 2, 3, 4, 5]
                    .map(
                      (n) => `
                    <button type="button" class="star-pick-btn ${n <= selectedRating ? 'active' : ''}" data-star="${n}" aria-label="Rate ${n} stars">
                      ${icon('star', { size: 22, filled: n <= selectedRating })}
                    </button>
                  `
                    )
                    .join('')}
                </div>
              </div>
              <div class="form-group">
                <label class="form-label" for="review-comment">Tasting Review</label>
                <textarea id="review-comment" class="textarea" placeholder="Describe the aroma, body, acidity, or finish..." required></textarea>
                <div id="review-form-error" class="form-error"></div>
              </div>
              <button type="submit" class="btn btn-primary" id="review-submit-btn">Publish Review</button>
            </form>
          </div>

          <div class="glass-card review-list-card">
            <h2 class="font-display" style="font-size:1.4rem;margin-bottom:12px;">Community Reviews (<span id="reviews-total-count">${reviews.length}</span>)</h2>
            <div id="reviews-list-container">
              ${
                reviews.length === 0
                  ? `<div class="empty-state">No reviews yet. Be the first taster to share notes!</div>`
                  : reviews
                      .map(
                        (r) => `
                  <div class="review-item">
                    <div class="review-header">
                      <span class="review-author">${escapeHtml(r.userId?.name || 'Coffee Taster')}</span>
                      <span class="review-date">${new Date(r.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:4px;color:var(--brand-highlight);margin-bottom:6px;">
                      ${Array.from({ length: r.rating })
                        .map(() => icon('star', { size: 14, filled: true }))
                        .join('')}
                    </div>
                    <p style="font-size:0.92rem;color:var(--text-secondary);">${escapeHtml(r.comment)}</p>
                  </div>
                `
                      )
                      .join('')
              }
            </div>
          </div>
        </div>
      `;

      // Bind vote & favorite handlers
      document.getElementById('details-vote-btn')?.addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        const result = await submitVote(c._id);
        btn.disabled = false;
        if (result) {
          animateNumber(document.getElementById('details-vote-count'), result.totalVotes);
          await renderDetails();
        }
      });

      document.getElementById('details-fav-btn')?.addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        const resFav = await toggleFavorite(c._id, currentFavIds.has(c._id));
        btn.disabled = false;
        if (resFav) {
          currentFavIds = new Set((resFav.favorites || []).map((x) => x._id));
          await renderDetails();
        }
      });

      // Star picker
      document.querySelectorAll('#star-picker [data-star]').forEach((starBtn) => {
        starBtn.addEventListener('click', () => {
          selectedRating = Number(starBtn.dataset.star);
          document.querySelectorAll('#star-picker [data-star]').forEach((b) => {
            const n = Number(b.dataset.star);
            b.classList.toggle('active', n <= selectedRating);
            b.innerHTML = icon('star', { size: 22, filled: n <= selectedRating });
          });
        });
      });

      // Review submit
      document.getElementById('review-submit-form')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!getToken()) {
          requireAuthPrompt('publish a coffee review');
          return;
        }

        const commentInput = document.getElementById('review-comment');
        const errEl = document.getElementById('review-form-error');
        const submitBtn = document.getElementById('review-submit-btn');
        const comment = commentInput.value.trim();

        if (comment.length < 3) {
          errEl.textContent = 'Please enter at least 3 characters for your review.';
          return;
        }
        errEl.textContent = '';
        submitBtn.disabled = true;
        submitBtn.textContent = 'Publishing...';

        try {
          const revRes = await apiFetch('/api/reviews', {
            method: 'POST',
            body: JSON.stringify({
              coffeeId: c._id,
              rating: selectedRating,
              comment,
            }),
          });
          showToast(revRes.message || 'Review published!');
          await renderDetails();
        } catch (err) {
          errEl.textContent = err.message;
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Publish Review';
        }
      });
    } catch (err) {
      root.innerHTML = `<div class="glass-card empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  window.addEventListener('brewverse:auth-changed', renderDetails);
  await renderDetails();
}

async function initLeaderboardPage() {
  await refreshSessionIfNeeded();
  await loadLeaderboardAndAnalytics();
  window.addEventListener('resize', renderCharts);
  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) {
    themeBtn.addEventListener('click', () => setTimeout(renderCharts, 30));
  }
}

function initLoginPage() {
  const form = document.getElementById('login-form');
  const demoBtn = document.getElementById('demo-login-btn');
  const errEl = document.getElementById('login-error');

  if (demoBtn) {
    demoBtn.addEventListener('click', () => {
      document.getElementById('login-email').value = 'barista@brewverse.com';
      document.getElementById('login-password').value = 'Password123!';
      form.requestSubmit();
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errEl.textContent = '';
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;

      if (!email || !password) {
        errEl.textContent = 'Please enter your email and password.';
        return;
      }

      const btn = document.getElementById('login-submit-btn');
      btn.disabled = true;
      btn.textContent = 'Signing in...';

      try {
        const res = await apiFetch('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        });
        saveSession(res.token, res.user);
        showToast(res.message);
        setTimeout(() => {
          window.location.href = '/';
        }, 450);
      } catch (err) {
        errEl.textContent = err.message;
      } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
      }
    });
  }
}

function initRegisterPage() {
  const form = document.getElementById('register-form');
  const errEl = document.getElementById('register-error');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errEl.textContent = '';
      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const password = document.getElementById('reg-password').value;

      if (name.length < 2) {
        errEl.textContent = 'Name must be at least 2 characters.';
        return;
      }
      if (!/^\S+@\S+\.\S+$/.test(email)) {
        errEl.textContent = 'Please enter a valid email address.';
        return;
      }
      if (password.length < 6) {
        errEl.textContent = 'Password must be at least 6 characters.';
        return;
      }

      const btn = document.getElementById('register-submit-btn');
      btn.disabled = true;
      btn.textContent = 'Creating account...';

      try {
        const res = await apiFetch('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({ name, email, password }),
        });
        saveSession(res.token, res.user);
        showToast(res.message);
        setTimeout(() => {
          window.location.href = '/';
        }, 450);
      } catch (err) {
        errEl.textContent = err.message;
      } finally {
        btn.disabled = false;
        btn.textContent = 'Create Account';
      }
    });
  }
}

async function initProfilePage() {
  const root = document.getElementById('profile-root');
  if (!root) return;

  if (!getToken()) {
    root.innerHTML = `
      <div class="glass-card empty-state" style="max-width:520px;margin:40px auto;">
        <h1 class="font-display" style="font-size:1.7rem;margin-bottom:10px;">Your BREWVERSE Profile</h1>
        <p style="margin-bottom:20px;">Sign in to view your saved favorites, voting ledger, and submitted reviews.</p>
        <div style="display:flex;gap:12px;justify-content:center;">
          <a href="/login.html" class="btn btn-primary">Sign In</a>
          <a href="/register.html" class="btn btn-outline">Create Account</a>
        </div>
      </div>
    `;
    return;
  }

  try {
    const data = await apiFetch('/api/auth/me');
    const user = data.user || getStoredUser();
    const votes = data.votes || [];
    const reviews = data.reviews || [];
    const favorites = user.favorites || [];

    root.innerHTML = `
      <div class="glass-card" style="padding:28px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:18px;margin-bottom:28px;">
        <div>
          <div style="font-size:0.84rem;color:var(--brand-secondary);font-weight:600;">Community Taster</div>
          <h1 class="font-display" style="font-size:2rem;margin:4px 0;">${escapeHtml(user.name)}</h1>
          <div style="font-size:0.9rem;color:var(--text-muted);">${escapeHtml(user.email)}</div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;">
          <button type="button" id="logout-btn" class="btn btn-outline btn-sm">Sign Out</button>
        </div>
      </div>

      <div class="kpi-strip" style="margin-top:0;margin-bottom:32px;">
        <div class="glass-card kpi-card">
          <div class="kpi-label">Active Votes</div>
          <div class="kpi-value tabular-nums">${votes.length}</div>
        </div>
        <div class="glass-card kpi-card">
          <div class="kpi-label">Saved Favorites</div>
          <div class="kpi-value tabular-nums">${favorites.length}</div>
        </div>
        <div class="glass-card kpi-card">
          <div class="kpi-label">Reviews Written</div>
          <div class="kpi-value tabular-nums">${reviews.length}</div>
        </div>
      </div>

      <div class="details-layout" style="margin-bottom:32px;">
        <div class="glass-card" style="padding:24px;">
          <h2 class="font-display" style="font-size:1.35rem;margin-bottom:14px;">Saved Favorites</h2>
          ${
            favorites.length === 0
              ? `<p style="color:var(--text-muted);font-size:0.92rem;">No favorites saved yet. Explore the collection to add some.</p>`
              : favorites
                  .map(
                    (c) => `
              <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-hairline);">
                <a href="/coffee-details.html?id=${c._id}" style="font-weight:600;">${escapeHtml(c.name)}</a>
                <button type="button" class="btn btn-ghost btn-sm" data-remove-fav="${c._id}">Remove</button>
              </div>
            `
                  )
                  .join('')
          }
        </div>

        <div class="glass-card" style="padding:24px;">
          <h2 class="font-display" style="font-size:1.35rem;margin-bottom:14px;">Your Voted Coffees</h2>
          ${
            votes.length === 0
              ? `<p style="color:var(--text-muted);font-size:0.92rem;">You haven't cast any votes yet.</p>`
              : votes
                  .map((v) =>
                    v.coffeeId
                      ? `
                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-hairline);">
                  <a href="/coffee-details.html?id=${v.coffeeId._id}" style="font-weight:600;">${escapeHtml(v.coffeeId.name)}</a>
                  <button type="button" class="btn btn-ghost btn-sm" data-remove-vote="${v.coffeeId._id}">Withdraw Vote</button>
                </div>
              `
                      : ''
                  )
                  .join('')
          }
        </div>
      </div>

      <div class="glass-card" style="padding:24px;">
        <h2 class="font-display" style="font-size:1.35rem;margin-bottom:14px;">Your Reviews</h2>
        ${
          reviews.length === 0
            ? `<p style="color:var(--text-muted);font-size:0.92rem;">You haven't published any reviews yet.</p>`
            : reviews
                .map(
                  (r) => `
            <div class="review-item">
              <div class="review-header">
                <a href="/coffee-details.html?id=${r.coffeeId?._id || ''}" class="review-author">${escapeHtml(
                    r.coffeeId?.name || 'Coffee'
                  )}</a>
                <span class="review-date">${r.rating} / 5 stars · ${new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
              <p style="font-size:0.92rem;color:var(--text-secondary);">${escapeHtml(r.comment)}</p>
            </div>
          `
                )
                .join('')
        }
      </div>
    `;

    document.getElementById('logout-btn')?.addEventListener('click', () => {
      clearSession();
      showToast('Signed out successfully.');
      window.location.href = '/';
    });

    root.querySelectorAll('[data-remove-fav]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const res = await toggleFavorite(btn.dataset.removeFav, true);
        if (res) initProfilePage();
      });
    });

    root.querySelectorAll('[data-remove-vote]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const res = await submitVote(btn.dataset.removeVote, { action: 'remove' });
        if (res) initProfilePage();
      });
    });
  } catch (err) {
    root.innerHTML = `<div class="glass-card empty-state">${escapeHtml(err.message)}</div>`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initHeaderChrome();
  const page = document.body.dataset.page;

  if (page === 'home') initHomePage();
  else if (page === 'coffee-details') initCoffeeDetailsPage();
  else if (page === 'leaderboard') initLeaderboardPage();
  else if (page === 'login') initLoginPage();
  else if (page === 'register') initRegisterPage();
  else if (page === 'profile') initProfilePage();
});
