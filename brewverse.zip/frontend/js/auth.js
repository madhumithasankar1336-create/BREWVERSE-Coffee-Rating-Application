import { icon } from './icons.js';
import { initBeamsBackground } from './beams.js';

const TOKEN_KEY = 'brewverse_token';
const USER_KEY = 'brewverse_user';
const THEME_KEY = 'brewverse_theme';

let beamsController = null;

export function getToken() {
  return localStorage.getItem(TOKEN_KEY) || '';
}

export function getStoredUser() {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveSession(token, user) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  updateHeaderAuth();
}

export function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  updateHeaderAuth();
}

export async function apiFetch(url, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({
    success: false,
    message: 'Unexpected server response.',
  }));

  if (!res.ok) {
    const error = new Error(data.message || `Request failed (${res.status})`);
    error.status = res.status;
    error.data = data;
    throw error;
  }

  return data;
}

export function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    container.setAttribute('aria-live', 'polite');
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${icon(type === 'error' ? 'close' : 'check', { size: 16 })}</span>
    <span>${escapeHtml(message)}</span>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';
    toast.style.transition = 'opacity 180ms ease, transform 180ms ease';
    setTimeout(() => toast.remove(), 200);
  }, 3200);
}

export function escapeHtml(str) {
  return String(str ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

export function initThemeAndBeams() {
  const saved = localStorage.getItem(THEME_KEY);
  const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  const isDark = saved ? saved === 'dark' : Boolean(prefersDark);

  document.documentElement.classList.toggle('dark', isDark);

  const beamsEl = document.getElementById('beams-bg');
  if (beamsEl && !beamsController) {
    beamsController = initBeamsBackground(beamsEl, getBeamsOptions(isDark));
  }

  syncThemeButton(isDark);
}

function getBeamsOptions(isDark) {
  if (isDark) {
    return {
      lightMode: false,
      color: '#c68b59',
      opacity: 0.36,
      brightness: 1.35,
      glow: 0.55,
      beamWidth: 140,
      rotation: 30,
      speed: 0.85,
    };
  }
  return {
    lightMode: true,
    color: '#3b2418',
    opacity: 0.14,
    brightness: 1.2,
    glow: 0.4,
    beamWidth: 140,
    rotation: 30,
    speed: 0.85,
  };
}

function syncThemeButton(isDark) {
  const btn = document.getElementById('theme-toggle-btn');
  if (!btn) return;
  btn.innerHTML = icon(isDark ? 'sun' : 'moon', { size: 18 });
  btn.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
  btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
}

export function toggleTheme() {
  const nextDark = !document.documentElement.classList.contains('dark');
  document.documentElement.classList.toggle('dark', nextDark);
  localStorage.setItem(THEME_KEY, nextDark ? 'dark' : 'light');
  syncThemeButton(nextDark);
  if (beamsController) {
    beamsController.updateOptions(getBeamsOptions(nextDark));
  }
}

export function updateHeaderAuth() {
  const user = getStoredUser();
  const authAction = document.getElementById('header-auth-btn');
  const mobileAuthAction = document.getElementById('mobile-auth-link');

  if (authAction) {
    if (user) {
      const firstName = user.name.split(' ')[0];
      authAction.href = '/profile.html';
      authAction.textContent = firstName;
      authAction.className = 'btn btn-outline btn-sm';
    } else {
      authAction.href = '/login.html';
      authAction.textContent = 'Sign In';
      authAction.className = 'btn btn-primary btn-sm';
    }
  }

  if (mobileAuthAction) {
    mobileAuthAction.href = user ? '/profile.html' : '/login.html';
    mobileAuthAction.textContent = user ? `Profile (${user.name.split(' ')[0]})` : 'Sign In';
  }
}

export function initHeaderChrome() {
  initThemeAndBeams();
  updateHeaderAuth();

  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) {
    themeBtn.addEventListener('click', toggleTheme);
  }

  const menuBtn = document.getElementById('mobile-menu-btn');
  const drawer = document.getElementById('mobile-nav-drawer');
  if (menuBtn && drawer) {
    menuBtn.innerHTML = icon('menu', { size: 18 });
    menuBtn.addEventListener('click', () => {
      const isOpen = drawer.classList.toggle('open');
      menuBtn.innerHTML = icon(isOpen ? 'close' : 'menu', { size: 18 });
      menuBtn.setAttribute('aria-expanded', String(isOpen));
    });
  }
}

export function requireAuthPrompt(actionLabel = 'vote or save favorites') {
  let modal = document.getElementById('auth-prompt-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'auth-prompt-modal';
    modal.className = 'modal-backdrop';
    modal.innerHTML = `
      <div class="modal-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-modal-title">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
          <h3 id="auth-modal-title" class="font-display" style="font-size:1.45rem;">Sign in to BREWVERSE</h3>
          <button type="button" class="icon-btn" id="close-auth-modal" aria-label="Close modal">${icon('close', { size: 16 })}</button>
        </div>
        <p id="auth-modal-desc" style="color:var(--text-secondary);font-size:0.93rem;margin-bottom:20px;"></p>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <a href="/login.html" class="btn btn-primary" style="width:100%;">Sign In to Your Account</a>
          <a href="/register.html" class="btn btn-outline" style="width:100%;">Create Free Taster Account</a>
          <button type="button" id="quick-demo-signin" class="btn btn-ghost" style="width:100%;">
            Continue as Demo Taster (Elena Vance)
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('#close-auth-modal').addEventListener('click', () => {
      modal.classList.remove('open');
    });
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('open');
    });

    modal.querySelector('#quick-demo-signin').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      btn.textContent = 'Signing in...';
      try {
        const res = await apiFetch('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            email: 'barista@brewverse.com',
            password: 'Password123!',
          }),
        });
        saveSession(res.token, res.user);
        modal.classList.remove('open');
        showToast(res.message || 'Signed in as Demo Taster!');
        window.dispatchEvent(new CustomEvent('brewverse:auth-changed'));
      } catch (err) {
        showToast(err.message, 'error');
      } finally {
        btn.disabled = false;
        btn.textContent = 'Continue as Demo Taster (Elena Vance)';
      }
    });
  }

  const desc = modal.querySelector('#auth-modal-desc');
  if (desc) {
    desc.textContent = `Create a free account or sign in to ${actionLabel}. Every vote and review is permanently recorded in the community ledger.`;
  }
  modal.classList.add('open');
}

export async function refreshSessionIfNeeded() {
  if (!getToken()) return null;
  try {
    const data = await apiFetch('/api/auth/me');
    if (data.user) {
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      updateHeaderAuth();
      return data;
    }
  } catch (err) {
    if (err.status === 401) {
      clearSession();
    }
  }
  return null;
}
